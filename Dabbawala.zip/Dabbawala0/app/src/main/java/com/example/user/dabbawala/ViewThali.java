package com.example.user.dabbawala;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewThali extends AppCompatActivity {
    String filter="",r="";
    int position;
    ListView lv;

    ArrayList<HashMap<String,String>> arrayList;
    ViewThaliAdapter simpleAdapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_thali);
        lv = (ListView) findViewById(R.id.listView);
        registerForContextMenu(lv);


        DB_Conn obj = new DB_Conn();
        obj.execute();


        final EditText txt_search=(EditText)findViewById(R.id.txt_search);

        txt_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {


            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter = txt_search.getText().toString();

                DB_Conn obj = new DB_Conn();
                obj.execute();
            }
        });
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Select an Action");

        menu.add(0, v.getId(), 0, "Edit");//groupId, itemId, order, title
        menu.add(1, v.getId(), 0, "Delete");


        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;

    }

    public boolean onContextItemSelected(MenuItem item){

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        View t=(View)info.targetView;

        r=((TextView)t.findViewById(R.id.txt_tno)).getText().toString();

       if(item.getTitle()=="Edit"){
            t.setBackgroundColor(Color.WHITE);
            Intent i=new Intent(this,EditThali.class);
            i.putExtra("tid",r);
            startActivity(i);

        }
        else if(item.getTitle()=="Delete"){
            t.setBackgroundColor(Color.WHITE);
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Delete Thali");
            alert.setMessage("Do you want to delete the selected thali?");
            alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface obj, int x) {
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            ViewThaliAdapter.delete(r);


                        }
                    };
                    Thread t = new Thread(runnable);
                    t.start();
                    arrayList.remove(position);
                    simpleAdapter1.notifyDataSetChanged();
                    Toast.makeText(ViewThali.this, "Thali deleted", Toast.LENGTH_SHORT).show();

                }
            });
            alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface obj, int x) {


                }
            });
            AlertDialog alertDialog = alert.create();
            alertDialog.show();
        }

        else{
            return false;
        }

        return true;
    }





    class DB_Conn extends AsyncTask<Void,Integer,String>
    {

        String[] from={"tno","name","price","type","description"};//string array
        int[] to={R.id.txt_tno,R.id.txt_name,R.id.txt_price,R.id.txt_type,R.id.txt_desc};//int array of views id's
        PreparedStatement pst;
        @Override
        public String doInBackground(Void... arg) //compulsory to implement
        {
            arrayList=new ArrayList<>();
            String r="";

            try {

                Connection con=DB_Connection.get_DBConnection();
                if(filter.equals("")) {
                    pst = con.prepareStatement("select * from thali");

                }
                else
                {
                    pst = con.prepareStatement("select * from thali where tid like ? or name like ? or type like ? or price like ?");
                    pst.setString(1,"%"+filter+"%");
                    pst.setString(2,"%"+filter+"%");
                    pst.setString(3,"%"+filter+"%");
                    pst.setString(4,"%"+filter+"%");
                }

                ResultSet rs = pst.executeQuery();



                if (rs.next()) {

                    do {


                        HashMap<String,String> hashMap=new HashMap<>();//create a hashmap to store the data in key value pair
                        hashMap.put("tno",rs.getString("tid"));
                        hashMap.put("name",rs.getString("name"));
                        hashMap.put("price",rs.getString("price"));
                        hashMap.put("type", rs.getString("type"));
                        hashMap.put("description", rs.getString("description"));

                        arrayList.add(hashMap);//add the hashmap into arrayList
                    }
                    while(rs.next());

                    r = "success";

                }
                else
                {
                    r="failure";
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Integer...arg0) //optional
        {


        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
                simpleAdapter1 = new ViewThaliAdapter(ViewThali.this, arrayList, R.layout.thalilist, from, to);//Create object and set the parameters for simpleAdapter
                lv.setAdapter(simpleAdapter1);//sets the adapter for listView
                //  Intent i=new Intent(Login.this,MainActivity_Admin.class);
                //startActivity(i);
                //Login.this.finish();


            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(ViewThali.this);
                alert.setTitle("Error");
                alert.setMessage("No records found to display");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {


                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }


}



