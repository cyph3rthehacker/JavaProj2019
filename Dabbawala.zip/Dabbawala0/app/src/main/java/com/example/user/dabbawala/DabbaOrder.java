package com.example.user.dabbawala;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DabbaOrder extends AppCompatActivity implements View.OnClickListener,AdapterView.OnItemSelectedListener {

    TextView txt_oid,txt_date,txt_expiry,txt_amt;
    EditText txt_pick,txt_drop;
    Spinner s1;
    String oid,p,edate,pick,drop;
    int amt=0;
    ArrayAdapter adapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dabba_order);

        txt_oid=(TextView)findViewById(R.id.textView21);
        txt_date=(TextView)findViewById(R.id.textView23);
        txt_date.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        txt_expiry=(TextView)findViewById(R.id.textView24);
        txt_amt=(TextView)findViewById(R.id.textView25);
        s1=(Spinner)findViewById(R.id.spinner3);
        String c[] = {"1 Month", "3 Months","6 Months","1 Year"};
        adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, c);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        s1.setAdapter(adapter1);
        s1.setOnItemSelectedListener(this);

        txt_pick=(EditText)findViewById(R.id.txt_pick);
        txt_drop=(EditText)findViewById(R.id.txt_drop);

        Button b1=(Button)findViewById(R.id.button5);
        b1.setOnClickListener(this);

        DB_Conn1 obj1 = new DB_Conn1();
        obj1.execute();

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {


            p=s1.getSelectedItem().toString();
            if(p.equalsIgnoreCase("1 month"))
            {
                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.MONTH,1);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);
                amt=400;
                txt_amt.setText("Amt: "+amt+"/-");
            }
            else if(p.equalsIgnoreCase("3 months"))
            {

                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.MONTH,3);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);
                amt=1200;
                txt_amt.setText("Amt: "+amt+"/-");

            }
            else if(p.equalsIgnoreCase("6 months"))
            {

                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.MONTH,6);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);
                amt=2400;
                txt_amt.setText("Amt: "+amt+"/-");

            }
            else if(p.equalsIgnoreCase("1 year"))
            {

                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.YEAR,1);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);
                amt=4800;
                txt_amt.setText("Amt: "+amt+"/-");
            }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    class DB_Conn1 extends AsyncTask<Void,Void,String> {

        String oid="";

        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {

            try {

                Connection con=DB_Connection.get_DBConnection();

                Calendar cl=Calendar.getInstance();

                PreparedStatement pst=con.prepareStatement("select max(oid) from dabbaorders");
                ResultSet rs=pst.executeQuery();
                rs.next();
                String v=rs.getString(1);
                if(v!=null)
                {
                    if(String.valueOf(cl.get(Calendar.YEAR)).equals(v.substring(1,5)))
                    {
                        int v1=Integer.parseInt(v.substring(v.length()-5));
                        v1=v1+1;
                        oid="D"+cl.get(Calendar.YEAR)+String.format("%05d",v1);
                    }
                    else
                    {
                        oid="D"+cl.get(Calendar.YEAR)+"00001";
                    }
                }
                else
                {

                    oid="D"+cl.get(Calendar.YEAR)+"00001";
                }
                pst.close();



            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            txt_oid.setText(oid);
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }


    @Override
    public void onClick(View view) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);
        oid=txt_oid.getText().toString().trim();
        pick=txt_pick.getText().toString().trim();
        drop=txt_drop.getText().toString().trim();
        edate=txt_expiry.getText().toString().trim();
        String a=txt_amt.getText().toString().trim();
        a=a.substring(5,a.indexOf('/'));
        amt=Integer.parseInt(a);

        if(pick.equals("")==false){
            if(drop.equals("")==false){

                Intent i=new Intent(DabbaOrder.this,Payment.class);
                i.putExtra("oid",oid);
                i.putExtra("userid", userid);
                i.putExtra("odate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                i.putExtra("pick", pick);
                i.putExtra("drop", drop);
                i.putExtra("period", p);
                i.putExtra("ordertype","dabba");
                try {
                    edate=new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("dd/MM/yyyy").parse(edate));
                    i.putExtra("expiry", edate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                i.putExtra("amt", amt);
                i.putExtra("p1", Html.fromHtml("<b>Order Confirmation<br/>Congratulations,<br/><br/> Your order has been placed successfully.<br/> Details are as follows:</b><br/>Order ID:" +oid+"<br/> Date: "+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+"<br/> Pickup: "+pick+"<br/>Drop: "+drop+"<br/>Period: "+p+"<br/>Expiry: "+edate+"<br/>Amt: "+amt).toString());
                i.putExtra("p2", "Order Confirmation\nCongratulations,\n\nYour order has been placed successfully.\nDetails are as follows:\nOrder ID:" +oid+"\nDate: "+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+"\nPickup: "+pick+"\nDrop: "+drop+"\nPeriod: "+p+"\nExpiry: "+edate+"\nAmt: "+amt);

                startActivity(i);
            }
            else{
                txt_drop.setError("Value is required");
            }

        }
        else{
            txt_pick.setError("Value is required");
        }

    }
}
