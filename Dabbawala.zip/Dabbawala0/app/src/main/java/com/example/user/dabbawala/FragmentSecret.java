package com.example.user.dabbawala;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentSecret extends Fragment {


    public FragmentSecret() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final String userid=getArguments().getString("userid");
        final String question=getArguments().getString("question");
        final String answer=getArguments().getString("answer");

        View v=inflater.inflate(R.layout.fragment_fragment_secret, container, false);
        TextView t1=(TextView)(v.findViewById(R.id.textView13));
        t1.setText(question);

        final EditText txt_answer = (EditText) v.findViewById(R.id.editText4);

        Button b1=(Button)v.findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String answer1 = txt_answer.getText().toString();

                if (answer.equals(answer1) == true) {

                    Intent i=new Intent(getActivity().getApplicationContext(),ResetPassword.class);
                    i.putExtra("userid",userid);
                    startActivity(i);

                } else {
                    AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
                    alert.setTitle("Error");
                    alert.setMessage("Wrong Answer... Please try again...");
                    alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface obj, int x) {

                        }
                    });
                    AlertDialog alertDialog = alert.create();
                    alertDialog.show();
                }
            }
        });
        return v;
    }

}
