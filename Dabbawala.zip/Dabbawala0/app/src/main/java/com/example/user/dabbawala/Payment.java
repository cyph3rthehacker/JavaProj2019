package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Payment extends AppCompatActivity implements View.OnClickListener {

    EditText txt_cno,txt_cvv,txt_name;
    TextView txt_amt;
    Spinner year,month;
    ArrayAdapter adapter1;
    ArrayAdapter adapter2;
    int finalamt=0;
    String t="";
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

       // Connection con=DB_Connection.get_DBConnection();

        i=getIntent();
        finalamt=i.getIntExtra("amt",0);


        txt_cno=(EditText)findViewById(R.id.txt_cno);

        txt_cvv=(EditText)findViewById(R.id.txt_cvv);
        txt_name=(EditText)findViewById(R.id.txt_name);
        txt_amt=(TextView)findViewById(R.id.txt_amt);
        txt_amt.setText("To pay: "+finalamt+" /-");

        year=(Spinner)findViewById(R.id.year);
        String c[] =new String[15];
        for(int j=0;j<=14;j++)
        {
            c[j]=(new java.util.GregorianCalendar().get(Calendar.YEAR)+j)+"";
        }

        adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, c);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        year.setAdapter(adapter1);


        month=(Spinner)findViewById(R.id.month);

        String c1[] =new String[12];
        for(int j=0;j<=11;j++)
        {
            c1[j]=(String.format("%02d",(j+1)));
        }

        adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, c1);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
        month.setAdapter(adapter2);

        Button b1=(Button) findViewById(R.id.button21);
        b1.setOnClickListener(this);

        txt_cno.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {


            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if(txt_cno.getText().toString().trim().equals("")==false && txt_cno.getText().length()==16) {
                    String a = txt_cno.getText().toString();
                    int n[] = new int[16];
                    int sum = 0;
                    for (int i = 0; i < a.length(); i++) {
                        n[i] = Integer.parseInt(a.charAt(i) + "");
                    }
                    for (int i = 15; i >= 0; i--) {
                        if (i % 2 == 0) {
                            n[i] = n[i] + n[i];
                            if (n[i] >= 10) {
                                n[i] = (n[i] / 10) + (n[i] % 10);
                            }
                        }
                    }
                    for (int i = 0; i < 16; i++) {
                        sum = sum + n[i];
                    }
                    if (sum % 10 != 0) {
                        txt_cno.requestFocus();
                        txt_cno.setError("Invalid credit card no", null);

                    }
                    else if (a.substring(0, 1).equals("4")) {
                        Drawable img = getResources().getDrawable(R.drawable.visa1);
                        img.setBounds(0, 0, 50, 50);
                        txt_cno.setCompoundDrawables(null, null, img, null);
                    } else if (Integer.parseInt(a.substring(0, 2)) >= 51 && Integer.parseInt(a.substring(0, 2)) <= 55) {
                        Drawable img = getResources().getDrawable(R.drawable.m1);
                        img.setBounds(0, 0, 100, 80);
                        txt_cno.setCompoundDrawables(null, null, img, null);
                    } else if (a.substring(0, 4).equals("6011") || a.substring(0, 2).equals("65")) {
                        Drawable img = getResources().getDrawable(R.drawable.dis1);
                        img.setBounds(0, 0, 50, 50);
                        txt_cno.setCompoundDrawables(null, null, img, null);
                    } else if (a.substring(0, 2).equals("34") || a.substring(0, 2).equals("37")) {
                        Drawable img = getResources().getDrawable(R.drawable.am1);
                        img.setBounds(0, 0, 50, 50);
                        txt_cno.setCompoundDrawables(null, null, img, null);
                    }
                }
                else{

                    txt_cno.setCompoundDrawables(null, null, null, null);
                }
            }
        });
    }
    @Override
    public void onClick(View v) {

        try {
            String name = txt_name.getText().toString().trim();
            String cno = txt_cno.getText().toString().trim();
            String cvv = txt_cvv.getText().toString().trim();


            String input = month.getSelectedItem().toString() + "/" + year.getSelectedItem().toString();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yyyy");
            simpleDateFormat.setLenient(false);
            Date expiry = simpleDateFormat.parse(input);
            boolean expired = expiry.before(new Date());

            if(cno.equals("")==false ) {
                if (name.equals("") == false) {
                    if (expired == false) {
                        if (cvv.equals("") == false) {
                            if(i.getStringExtra("ordertype").equals("dabba")){
                                DB_Conn3 obj1 = new DB_Conn3();
                                obj1.execute();
                            }
                            else{
                                DB_Conn1 obj1 = new DB_Conn1();
                                obj1.execute();

                            }

                        }
                        else {
                            txt_cvv.setError("Value is required");
                        }

                    }
                    else {
                        AlertDialog.Builder alert = new AlertDialog.Builder(Payment.this);
                        alert.setTitle("Error");
                        alert.setMessage("Card Expired");
                        alert.setPositiveButton("OK", null);
                        AlertDialog alertDialog = alert.create();
                        alertDialog.show();
                    }
                }
                else {
                    txt_name.setError("Value is required");
                }
            }
            else {
                txt_cno.setError("Value is required");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    class DB_Conn3 extends AsyncTask<Void,Void,String>
    {

        PreparedStatement pst;
        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {
            String r="";

            try {

                Connection con=DB_Connection.get_DBConnection();

                pst = con.prepareStatement("insert into dabbaorders values(?,?,?,?,?,?,?,?)");
                pst.setString(1, i.getStringExtra("oid"));
                pst.setString(2,i.getStringExtra("userid"));
                pst.setString(3, i.getStringExtra("odate"));
                pst.setString(4, i.getStringExtra("pick"));
                pst.setString(5, i.getStringExtra("drop"));
                pst.setString(6, i.getStringExtra("period"));
                pst.setString(7, i.getStringExtra("expiry"));
                pst.setInt(8, i.getIntExtra("amt",0));

                pst.execute();
                con.close();
                r = "success";



            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {


                Intent i1=new Intent(Payment.this,OrderInvoice.class);

                i1.putExtra("p1", Html.fromHtml(i.getStringExtra("p1")).toString());
                i1.putExtra("p2", i.getStringExtra("p2"));
                startActivity(i1);





            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(Payment.this);
                alert.setTitle("Error");
                alert.setMessage("Error occured");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {



                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }

    class DB_Conn1 extends AsyncTask<Void,Void,String>
    {


        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {
            String r="";
            try {

                r = "success";

            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {

                AlertDialog.Builder alert = new AlertDialog.Builder(Payment.this);
                alert.setTitle("Success");
                alert.setMessage("Payment processed successfully");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {
                        Intent i1=new Intent(Payment.this,OrderInvoice.class);
                        i1.putExtra("p1", Html.fromHtml(i.getStringExtra("p1")).toString());
                        i1.putExtra("p2", i.getStringExtra("p2"));
                        startActivity(i1);

                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }


        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}
