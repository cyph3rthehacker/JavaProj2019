package com.example.user.dabbawala;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;

public class MainPage extends AppCompatActivity implements View.OnClickListener {

    HorizontalScrollView s;
   // private AlarmManager am;
    //privateezq     PendingIntent pintent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        try {


      /*      am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, OTPSender.class);
            pintent = PendingIntent.getBroadcast(this, 0, intent, 0);

            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
            int curHr = calendar.get(Calendar.HOUR_OF_DAY);
            int min = calendar.get(Calendar.MINUTE);
            /*Log.i("HRRRRRRRRR", curHr + "");
            Log.i("MINNNNNNNN", min + "");

            Date d1 = new SimpleDateFormat("HH:mm").parse(curHr + ":" + min);
            Date d2 = new SimpleDateFormat("HH:mm").parse("20:28");
            long elapsed = d1.getTime() - d2.getTime();

            Log.i("Elapsedddddddd", elapsed + "");
            //Checking whether current hour is over 14
            if (elapsed>=1) {
                // Since current hour is over 14, setting the date to the next day
                calendar.add(Calendar.DATE, 1);
            }


            calendar.set(Calendar.HOUR_OF_DAY, 06);
            calendar.set(Calendar.MINUTE, 00);

            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), am.INTERVAL_DAY, pintent);
            // am.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(), 4000, pintent);*/

            ImageButton b1 = (ImageButton) findViewById(R.id.button8);
            b1.setOnClickListener(this);
            ImageButton b2 = (ImageButton) findViewById(R.id.button9);
            b2.setOnClickListener(this);
            ImageButton b3 = (ImageButton) findViewById(R.id.button10);
            b3.setOnClickListener(this);
            ImageButton b4 = (ImageButton) findViewById(R.id.button11);
            b4.setOnClickListener(this);
            ImageButton b5 = (ImageButton) findViewById(R.id.button12);
            b5.setOnClickListener(this);
            ImageButton b7 = (ImageButton) findViewById(R.id.button90);
            b7.setOnClickListener(this);

            add();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void add() {
        s = (HorizontalScrollView) findViewById(R.id.scrollAuto);

        s.postDelayed(new Runnable() {
            public void run() {
                s.fullScroll(HorizontalScrollView.FOCUS_LEFT);
                s.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
            }
        }, 100L);
    }

    public void onClick(View v)
    {
        add();
        if(v.getId()==R.id.button8) {
            Intent i = new Intent(this, PlaceOrder.class);
            startActivity(i);
        }
         else if(v.getId()==R.id.button9) {

            Intent i = new Intent(this, DabbaOrder.class);
            startActivity(i);

        }
        else if(v.getId()==R.id.button10)
        {
           Intent i=new Intent(this,ViewDabbaOrders.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button11)
        {
            Intent i=new Intent(this,ChangePassword.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button90)
        {
            Intent i=new Intent(this,ViewThaliOrders.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button12)
        {

            SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
            SharedPreferences.Editor ed = sp.edit();
            ed.clear();
            ed.commit();

            Intent i=new Intent(this,Login.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.icon, menu);
        return true;
    }
}
