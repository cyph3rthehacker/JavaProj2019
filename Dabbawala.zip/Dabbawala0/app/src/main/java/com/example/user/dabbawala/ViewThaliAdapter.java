package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by shruti on 3/27/2018.
 */
public class ViewThaliAdapter extends SimpleAdapter {
    LayoutInflater inflater;
    Context context;
    ArrayList<HashMap<String, String>> arrayList;

    public ViewThaliAdapter(Context context, ArrayList<HashMap<String, String>> data, int resource, String[] from, int[] to) {
        super(context, data, resource, from, to);
        this.context = context;
        this.arrayList = data;
        //inflater.from(context);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        TextView t=(TextView)view.findViewById(R.id.txt_tno);
        final String r1=t.getText().toString();
        ImageButton imagebutton = (ImageButton) view.findViewById(R.id.imageButton);
        imagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setTitle("Delete Thali");
                alert.setMessage("Do you want to delete the selected thali?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {
                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {
                                delete(r1);


                            }
                        };
                        Thread t = new Thread(runnable);
                        t.start();
                        arrayList.remove(position);
                        notifyDataSetChanged();
                        Toast.makeText(context, "Thali record deleted", Toast.LENGTH_SHORT).show();

                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {


                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        });
        return view;
    }
    public static void delete(String r1)
    {
        try
        {
            Connection con = DB_Connection.get_DBConnection();
            PreparedStatement pst = con.prepareStatement("delete from thali where tid=?");
            pst.setString(1, r1);
            pst.executeUpdate();
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

