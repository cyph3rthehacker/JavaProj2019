package com.example.user.dabbawala;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);





        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app
              * logo / company
             */

            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity
                SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
                boolean l = sp.getBoolean("loggedin", false);
                String userid = sp.getString("userid", null);
                if (l == true) {
                    if (userid.equalsIgnoreCase("admin@dabbawala.com")) {
                        Intent i = new Intent(SplashScreen.this, MainPage_Admin.class);
                        startActivity(i);
                    }
                    else if(userid.equals("delivery@dabbawala.com")){
                        Intent i = new Intent(SplashScreen.this, DabbaDeliveryList.class);
                        startActivity(i);
                    }
                    else  {
                        Intent i = new Intent(SplashScreen.this, MainPage.class);
                        startActivity(i);
                    }



                }
                else {
                    Intent i = new Intent(SplashScreen.this, Login.class);
                    startActivity(i);
                }

                // close this activity
                finish();
            }
        }, 3000);
    }
}
