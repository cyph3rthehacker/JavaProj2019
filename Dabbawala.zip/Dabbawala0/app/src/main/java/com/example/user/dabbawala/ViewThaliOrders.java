package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewThaliOrders extends AppCompatActivity {

    ListView lv;

    ArrayList<HashMap<String,String>> arrayList;
    SimpleAdapter simpleAdapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_thali_orders);
        lv = (ListView) findViewById(R.id.listviewthali);

        DB_Conn obj = new DB_Conn();
        obj.execute();

    }

    class DB_Conn extends AsyncTask<Void,Integer,String> {

        String[] from = {"oid", "userid", "odate", "type", "tname", "period", "edate", "qty", "time", "price", "amt", "address"};//string array
        int[] to = {R.id.textView33, R.id.textView34, R.id.textView35, R.id.textView36, R.id.textView37, R.id.textView38, R.id.textView39, R.id.textView40, R.id.textView41, R.id.textView42, R.id.textView43, R.id.textView44};//int array of views id's
        PreparedStatement pst;

        @Override
        public String doInBackground(Void... arg) //compulsory to implement
        {
            arrayList = new ArrayList<>();
            String r = "";

            try {
                SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = sp.edit();
                String u = sp.getString("userid", null);

                Connection con = DB_Connection.get_DBConnection();

                if (u.equalsIgnoreCase("admin@dabbawala.com"))
                    pst = con.prepareStatement("select * from orders");
                else {
                    pst = con.prepareStatement("select * from orders where userid=?");
                    pst.setString(1, u);
                }
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {

                    do {


                        HashMap<String, String> hashMap = new HashMap<>();//create a hashmap to store the data in key value pair
                        hashMap.put("oid", "Order ID: " + rs.getString(1));
                        hashMap.put("userid", "User ID: " + rs.getString(2));
                        hashMap.put("odate", "Order date: " + rs.getString(3));
                        hashMap.put("type", "Thali type: " + rs.getString(4));
                        hashMap.put("tname", "Thali name: " + rs.getString(5));
                        hashMap.put("period", "Period: " + rs.getString(6));
                        hashMap.put("edate", "Expiry date: " + rs.getString(7));
                        hashMap.put("qty", "Qty: " + rs.getString(8));
                        hashMap.put("time", "Time: " + rs.getString(9));
                        hashMap.put("price", "Price: " + rs.getString(10));
                        hashMap.put("amt", "Amount: " + rs.getString(11));
                        hashMap.put("address", "Address: " + rs.getString(12));

                        arrayList.add(hashMap);//add the hashmap into arrayList
                    }
                    while (rs.next());

                    r = "success";

                } else {
                    r = "failure";
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }

        @Override
        public void onProgressUpdate(Integer... arg0) //optional
        {


        }

        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if (result.equals("success")) {
                simpleAdapter1 = new SimpleAdapter(ViewThaliOrders.this, arrayList, R.layout.thaliorderslist, from, to);//Create object and set the parameters for simpleAdapter
                lv.setAdapter(simpleAdapter1);//sets the adapter for listView
                //  Intent i=new Intent(Login.this,MainActivity_Admin.class);
                //startActivity(i);
                //Login.this.finish();


            } else {
                AlertDialog.Builder alert = new AlertDialog.Builder(ViewThaliOrders.this);
                alert.setTitle("Error");
                alert.setMessage("No records found to display");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {

                        finish();
                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }

}
