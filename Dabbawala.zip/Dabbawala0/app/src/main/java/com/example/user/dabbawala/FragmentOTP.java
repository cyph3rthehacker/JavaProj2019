package com.example.user.dabbawala;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentOTP extends Fragment {


    public FragmentOTP() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final String userid=getArguments().getString("userid");
        final String otp=getArguments().getString("otp");


        View v=inflater.inflate(R.layout.fragment_fragment_otp, container, false);
        final EditText txt_otp = (EditText) v.findViewById(R.id.txt_otp);

        Button b1=(Button)v.findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String otp1 = txt_otp.getText().toString();

                if (otp.equals(otp1) == true) {

                    Intent i=new Intent(getActivity().getApplicationContext(),ResetPassword.class);
                    i.putExtra("userid",userid);
                    startActivity(i);

                } else {
                    AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
                    alert.setTitle("Error");
                    alert.setMessage("Incorrect OTP entered");
                    alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface obj, int x) {

                        }
                    });
                    AlertDialog alertDialog = alert.create();
                    alertDialog.show();
                }
            }
        });
        return v;
    }
}
