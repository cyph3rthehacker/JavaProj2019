package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TimePicker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class PlaceOrder extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener {

    EditText txt_oid,txt_date,txt_qty,txt_expiry,txt_price,txt_amt,txt_address;
    static EditText txt_time;
    RadioButton r1,r2;
    RadioGroup group;
    Spinner thali,period;
    ArrayAdapter adapter1,adapter2;
    String oid,odate,qty,p,t,thaliname,edate,time,price,amt,address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        txt_oid=(EditText)findViewById(R.id.txt_oid);
        txt_date=(EditText)findViewById(R.id.txt_date);
        txt_date.setText(new SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date()));

        txt_qty=(EditText)findViewById(R.id.txt_qty);
        txt_address=(EditText)findViewById(R.id.txt_address);
        txt_time=(EditText)findViewById(R.id.txt_time);
        txt_price=(EditText)findViewById(R.id.txt_price);
        txt_amt=(EditText)findViewById(R.id.txt_amt);
        txt_expiry=(EditText)findViewById(R.id.txt_expiry);
        group = (RadioGroup) findViewById(R.id.rg);
        r1=(RadioButton)findViewById(R.id.rd_veg);
        r2=(RadioButton)findViewById(R.id.rd_nonveg);
        thali=(Spinner)findViewById(R.id.spinner);
        period=(Spinner)findViewById(R.id.spinner2);
        period.setOnItemSelectedListener(this);
        period.setPrompt("Select Period");
        thali.setOnItemSelectedListener(this);
        thali.setPrompt("Select Thali");

        String c[] = {"1 Month", "3 Months","6 Months","1 Year"};
        adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, c);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        period.setAdapter(adapter1);

        Button b1=(Button)findViewById(R.id.button4);
        b1.setOnClickListener(this);


        DB_Conn1 obj1 = new DB_Conn1();
        obj1.execute();
        txt_time.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    TimePickerFragment newFragment = new TimePickerFragment();

                    newFragment.show(getSupportFragmentManager(), "timePicker");

                }
            }
        });

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                // TODO Auto-generated method stub
                if(r1.isChecked()) {
                    t="Veg";
                    DB_Conn2 obj1 = new DB_Conn2();
                    obj1.execute("Veg");
                } else if(r2.isChecked()) {
                    t="Non Veg";
                    DB_Conn2 obj1 = new DB_Conn2();
                    obj1.execute("Non Veg");

                }
            }
        });

        txt_qty.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {


            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(txt_qty.getText().toString().trim().equals("")==false && txt_price.getText().toString().trim().equals("")==false) {
                    try{
                        int q = Integer.parseInt(txt_qty.getText().toString().trim());
                        int p = Integer.parseInt(price);

                        SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy");
                        java.util.Date d1=f.parse(txt_date.getText().toString());
                        java.util.Date d2=f.parse(txt_expiry.getText().toString());
                        int days= (int)TimeUnit.MILLISECONDS.toDays(d2.getTime() - d1.getTime());
                        amt=""+days*q*p;
                        txt_amt.setText(""+amt);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }


                }
                else{
                    txt_amt.setText("");
                }

            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    public void onClick(View v)
    {
        oid=txt_oid.getText().toString().trim();
        odate=txt_date.getText().toString().trim();
        edate=txt_expiry.getText().toString().trim();
        qty=txt_qty.getText().toString().trim();
        thaliname=thali.getSelectedItem().toString();
        time=txt_time.getText().toString().trim();
        address=txt_address.getText().toString().trim();

        if(r1.isChecked()==true || r2.isChecked()==true){
            if(qty.equals("")==false && Integer.parseInt(qty)>0){
                if(time.equals("")==false){
                    if(address.equals("")==false){
                        DB_Conn3 obj3=new DB_Conn3();
                        obj3.execute();
                    }
                    else{
                        txt_address.setError("Value is required");
                    }
                }
                else{
                    txt_time.setError("Value is required");
                }
            }else{
                txt_qty.setError("Either qty is blank or Invalid value");
            }

        }
        else{
            r1.setError("Please select an option");
        }

    }
    class DB_Conn3 extends AsyncTask<Void,Void,String>
    {

        PreparedStatement pst;
        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {
            String r="";

            try {
                SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

                String userid = sp.getString("userid", null);


                Connection con=DB_Connection.get_DBConnection();

                pst = con.prepareStatement("insert into orders values(?,?,?,?,?,?,?,?,?,?,?,?)");
                pst.setString(1, oid);
                pst.setString(2, userid);
                pst.setString(3, new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("dd/MM/yyyy").parse(odate)));
                pst.setString(4, t);
                pst.setString(5, thaliname);
                pst.setString(6, p);
                pst.setString(7, new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("dd/MM/yyyy").parse(edate)));
                pst.setInt(8, Integer.parseInt(qty));
                pst.setString(9,time);
                pst.setInt(10, Integer.parseInt(price));
                pst.setInt(11, Integer.parseInt(amt));
                pst.setString(12, address);


                pst.execute();
                con.close();
                r = "success";



            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {


                        Intent i=new Intent(PlaceOrder.this,Payment.class);
                        i.putExtra("amt",Integer.parseInt(amt));
                        i.putExtra("ordertype","thali");
                        i.putExtra("p1",Html.fromHtml("<b>Order Confirmation<br/>Congratulations,<br/><br/> Your order has been placed successfully.<br/> Details are as follows:</b> <br/> Order ID:" +oid+"<br/> Type: "+t+"<br/> Thali name: "+t+"<br/>Period: "+p+"<br/>Quantity: "+qty+"<br/>Time: "+time+"<br/>Amt: "+amt+"<br/>Address: "+address).toString());
                        i.putExtra("p2","Order Confirmation\nCongratulations,\n\n Your order has been placed successfully.\nDetails are as follows:\n Order ID:" +oid+"\n Type: "+t+"\n Thali name: "+t+"\nPeriod: "+p+"\nQuantity: "+qty+"\nTime: "+time+"\nAmt: "+amt+"\nAddress: "+address);
                        startActivity(i);





            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(PlaceOrder.this);
                alert.setTitle("Error");
                alert.setMessage("Error occured");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {



                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }


    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        if(parent.getId()==R.id.spinner2){
            p=period.getSelectedItem().toString();
            if(p.equalsIgnoreCase("1 month"))
            {
                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.MONTH,1);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);
            }
            else if(p.equalsIgnoreCase("3 months"))
            {

                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.MONTH,3);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);

            }
            else if(p.equalsIgnoreCase("6 months"))
            {
                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.MONTH,6);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);

            }
            else if(p.equalsIgnoreCase("1 year"))
            {

                Calendar cl=Calendar.getInstance();
                cl.add(Calendar.YEAR,1);
                String date=String.format("%02d",cl.get(Calendar.DAY_OF_MONTH))+"/"+String.format("%02d",cl.get(Calendar.MONTH)+1)+"/"+cl.get(Calendar.YEAR);
                txt_expiry.setText(date);

            }

        }
        else
        {
            if(thali.getSelectedItem()!=null){

                thaliname = thali.getSelectedItem().toString();
                DB_Conn4 obj4 = new DB_Conn4();
                obj4.execute();
            }
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    public static class TimePickerFragment extends DialogFragment
            implements TimePickerDialog.OnTimeSetListener {


        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current time as the default values for the picker
            final Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);

            // Create a new instance of TimePickerDialog and return it


            TimePickerDialog t=new TimePickerDialog(getActivity(), this, hour, minute, true);
            TimePicker tp=new TimePicker(getActivity());
            tp.setIs24HourView(true);
            return new TimePickerDialog(getActivity(),2 ,this, hour, minute,true);

        }

        public void onTimeSet(TimePicker view, int h, int m) {
            // Do something with the time chosen by the user
            txt_time.setText(String.format("%02d:%02d", h, m));


        }
    }
    class DB_Conn4 extends AsyncTask<String,Void,String>{



        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {

            try {



                Connection con=DB_Connection.get_DBConnection();

                PreparedStatement pst=con.prepareStatement("select price from thali where name=?");
                pst.setString(1,thaliname);
                ResultSet rs=pst.executeQuery();
                rs.next();
                price=rs.getString("price");


            } catch (Exception e) {
                e.printStackTrace();
            }
            return "success";

        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
           txt_price.setText(price);
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
    class DB_Conn2 extends AsyncTask<String,Void,String>{

        String oid="";
        ArrayList<String> a1;

        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {

            try {
                a1=new ArrayList<>();


                Connection con=DB_Connection.get_DBConnection();

                Calendar cl=Calendar.getInstance();

                PreparedStatement pst=con.prepareStatement("select * from thali where type=?");
                pst.setString(1,arg[0]);
                ResultSet rs=pst.executeQuery();
                while(rs.next())
                {
                    a1.add(rs.getString("name"));
                }

                pst.close();



            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            adapter2 = new ArrayAdapter(PlaceOrder.this, android.R.layout.simple_spinner_item, a1);
            adapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
            thali.setAdapter(adapter2);
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
    class DB_Conn1 extends AsyncTask<Void,Void,String>{

        String oid="";

        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {

            try {

                Connection con=DB_Connection.get_DBConnection();

                Calendar cl=Calendar.getInstance();

                PreparedStatement pst=con.prepareStatement("select max(oid) from orders");
                ResultSet rs=pst.executeQuery();
                rs.next();
                String v=rs.getString(1);
                if(v!=null)
                {
                    if(String.valueOf(cl.get(Calendar.YEAR)).equals(v.substring(1,5)))
                    {
                        int v1=Integer.parseInt(v.substring(v.length()-5));
                        v1=v1+1;
                        oid="O"+cl.get(Calendar.YEAR)+String.format("%05d",v1);
                    }
                    else
                    {
                        oid="O"+cl.get(Calendar.YEAR)+"00001";
                    }
                }
                else
                {

                    oid="O"+cl.get(Calendar.YEAR)+"00001";
                }
                pst.close();



            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            txt_oid.setText(oid);
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}

