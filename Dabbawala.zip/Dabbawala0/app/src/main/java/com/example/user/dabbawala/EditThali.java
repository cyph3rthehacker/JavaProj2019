package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EditThali extends AppCompatActivity implements View.OnClickListener {

    EditText txt_id,txt_name,txt_desc,txt_price;
    String id,name,desc,price,type;
    RadioButton r1,r2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_thali);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent i=getIntent();
        id=i.getStringExtra("tid");

        Button b1=(Button)findViewById(R.id.btn_ok);
        b1.setOnClickListener(this);
        txt_id=(EditText)findViewById(R.id.txt_tid);
        txt_id.setText(id);
        txt_name=(EditText)findViewById(R.id.txt_name);
        txt_desc=(EditText)findViewById(R.id.txt_desc);
        txt_price=(EditText)findViewById(R.id.txt_price);
        r1=(RadioButton)findViewById(R.id.rd_veg);
        r2=(RadioButton)findViewById(R.id.rd_nonveg);
        DB_Conn obj = new DB_Conn();
        obj.execute("select");
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
    public void onClick(View v)
    {
        id=txt_id.getText().toString();
        name=txt_name.getText().toString();
        desc=txt_desc.getText().toString();
        price=txt_price.getText().toString();
        type=((RadioButton)findViewById(((RadioGroup)findViewById(R.id.rg)).getCheckedRadioButtonId())).getText().toString();

        if (name.equals("") == false) {
            if (desc.equals("") == false) {
                if (price.equals("") == false && Integer.parseInt(price)>0) {

                    DB_Conn obj = new DB_Conn();
                    obj.execute("update");
                }
                else {
                    txt_price.setError("Either price is blank or Invalid value");
                }
            } else {
                txt_desc.setError("Value is required");
            }
        } else{
            txt_name.setError("Value is required");
        }

    }
    class DB_Conn extends AsyncTask<String,Void,String>
    {

        ResultSet rs;

        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {
            String r="";
            try {

                Connection con=DB_Connection.get_DBConnection();

                if (arg[0].equals("select")) {

                    PreparedStatement pst = con.prepareStatement("select * from thali where tid=?");
                    pst.setString(1, id);
                    rs = pst.executeQuery();
                    rs.next();
                    r="successselect";

                }

                else if(arg[0].equals("update"))
                {
                    PreparedStatement pst1 = con.prepareStatement("update thali  set name=?, price=?,description=?, type=? where tid=?");
                    pst1.setString(1, name);
                    pst1.setInt(2, Integer.parseInt(price));
                    pst1.setString(3, desc);
                    pst1.setString(4, type);
                    pst1.setString(5, id);
                    pst1.executeUpdate();
                    pst1.close();


                    r="success";
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("successselect"))
            {
                /*sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = sp.edit();
                ed.putString("userid", u);
                ed.putBoolean("loggedin", true);

                ed.commit();

                //  Intent i=new Intent(Login.this,MainActivity_Admin.class);
                //startActivity(i);
                //Login.this.finish();*/
                try {
                    txt_name.setText(rs.getString("name"));
                    txt_desc.setText(rs.getString("description"));
                    txt_price.setText(rs.getString("price"));

                    if(rs.getString("type").equalsIgnoreCase("veg"))
                        r1.setChecked(true);
                    else
                        r2.setChecked(true);


                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }

            }

            else if(result.equals("success"))
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(EditThali.this);
                alert.setTitle("Success");
                alert.setMessage("Record updated successfully");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {
                        finish();

                    }
                });

                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}

