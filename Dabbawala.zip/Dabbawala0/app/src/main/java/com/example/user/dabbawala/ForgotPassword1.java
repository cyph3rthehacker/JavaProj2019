package com.example.user.dabbawala;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ForgotPassword1 extends AppCompatActivity {

    String userid,option;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent i=getIntent();
        userid=i.getStringExtra("userid");
        option=i.getStringExtra("option");

        if(option.equalsIgnoreCase("answer secret question")) {
            setContentView(R.layout.activity_forgot_password1);
            DB_Conn obj = new DB_Conn();
            obj.execute(userid);
        }
        else{

            DB_Conn1 obj1 = new DB_Conn1();
            obj1.execute(userid);

            pd = new ProgressDialog(this);
            pd.setMessage("Sending OTP on email..Please wait.."); // Setting Message
            pd.setTitle("Password Reset"); // Setting Title
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
            pd.show(); // Display Progress Dialog
            pd.setCancelable(false);

        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {


        switch(item.getItemId()) {
            case R.id.home:


                    Intent i = new Intent(this, Login.class);
                    startActivity(i);

                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }

    class DB_Conn1 extends AsyncTask<String,Void,String>
    {

        String u;
        String r="",otp;
        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {

            try {
                u=arg[0];
                Random r = new Random();
                otp = r.nextInt(9) + "" + r.nextInt(9) + "" + r.nextInt(9) + "" + r.nextInt(9);
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                p.put("mail.smtp.auth","true");
                p.put("mail.smtp.host","173.194.202.108");
                p.put("mail.smtp.port","587");

                Session s= Session.getDefaultInstance(p,new Authenticator()
                {
                    protected PasswordAuthentication getPasswordAuthentication()
                    {
                        return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                    }
                });


                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
                msg.addRecipient(Message.RecipientType.TO,new InternetAddress(u));//here type recipient email id
                msg.setSubject("OTP for registration");
                String m="Greeting,\n Your OTP for password reset is "+otp;
                msg.setContent(m, "text/html; charset=utf-8");
                Transport.send(msg);
                return "success";
            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success")) {
                pd.dismiss();

                setContentView(R.layout.activity_forgot_password1);
                FragmentOTP hf = new FragmentOTP();
                Bundle bundle=new Bundle();
                bundle.putString("userid", u);
                bundle.putString("otp", otp);
                hf.setArguments(bundle);

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.myfragment, hf);
                fragmentTransaction.commit();
            }


        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
    class DB_Conn extends AsyncTask<String,Void,String>
    {

        String u;
        String r="",question,answer;
        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {

            try {
                u=arg[0];
                Connection con=DB_Connection.get_DBConnection();

                PreparedStatement pst = con.prepareStatement("select * from users where emailid=?");
                pst.setString(1, arg[0]);

                ResultSet rs = pst.executeQuery();
                if (rs.next() == true) {
                    question=rs.getString("secret_question");
                    answer=rs.getString("answer");
                    r = "success";

                }

                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
                FragmentSecret hf = new FragmentSecret();
                Bundle bundle=new Bundle();
                bundle.putString("userid", u);
                bundle.putString("question", question);
                bundle.putString("answer", answer);
                hf.setArguments(bundle);

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.myfragment, hf);
                fragmentTransaction.commit();
            }


        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}
