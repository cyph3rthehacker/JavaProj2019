package com.example.user.dabbawala;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.HorizontalScrollView;

import java.sql.Time;

public class MainPage_Admin extends AppCompatActivity implements View.OnClickListener {

    HorizontalScrollView s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page__admin);

        ImageButton b1=(ImageButton)findViewById(R.id.button14);
        b1.setOnClickListener(this);
        ImageButton b2=(ImageButton)findViewById(R.id.button15);
        b2.setOnClickListener(this);
        ImageButton b3=(ImageButton)findViewById(R.id.button16);
        b3.setOnClickListener(this);
        ImageButton b4=(ImageButton)findViewById(R.id.button160);
        b4.setOnClickListener(this);
        ImageButton b5=(ImageButton)findViewById(R.id.button18);
        b5.setOnClickListener(this);
        ImageButton b6=(ImageButton)findViewById(R.id.button19);
        b6.setOnClickListener(this);
        add();
    }
public void add() {
    s = (HorizontalScrollView) findViewById(R.id.scrollAuto);

        s.postDelayed(new Runnable() {
            public void run() {
                s.fullScroll(HorizontalScrollView.FOCUS_LEFT);
                s.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
            }
        }, 100L);
    }

    public void onClick(View v)
    {
        add();
        if(v.getId()==R.id.button14)
        {
            Intent i=new Intent(this,AddThali.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button15)
        {
            Intent i=new Intent(this, ViewThali.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button16)
        {
            Intent i=new Intent(this,ViewThaliOrders.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button160)
        {
            Intent i=new Intent(this,ViewDabbaOrders.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button18)
        {
            Intent i=new Intent(this,ChangePassword.class);
            startActivity(i);
        }
        else if(v.getId()==R.id.button19)
        {
            SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
            SharedPreferences.Editor ed = sp.edit();
            ed.clear();
            ed.commit();

            Intent i=new Intent(this,Login.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.icon, menu);
        return true;
    }
}
