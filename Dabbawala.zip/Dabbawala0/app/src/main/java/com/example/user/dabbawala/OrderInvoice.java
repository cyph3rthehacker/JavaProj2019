package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class OrderInvoice extends AppCompatActivity {

    TextView t1;
    String m,m1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_invoice);
        Intent i=getIntent();

        m=i.getStringExtra("p1")+"";
        m1=i.getStringExtra("p2")+"";
        t1=(TextView)findViewById(R.id.textView22);

        t1.setText(m1);

        DB_Conn obj=new DB_Conn();
        obj.execute();

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    class DB_Conn extends AsyncTask<Void, Void, String> {


        String result="";
        @Override
        public String doInBackground(Void... arg) //compulsory to implement
        {

            try {

                SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

                String userid = sp.getString("userid", null);
                Properties p = new Properties();
                p.put("mail.smtp.starttls.enable", "true");//here smtp donot get start security gets started
                p.put("mail.smtp.auth", "true");
                p.put("mail.smtp.host", "173.194.202.108");
                p.put("mail.smtp.port", "587");

                Session s = Session.getDefaultInstance(p, new Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID, DB_Connection.SENDERS_PASSWORD);
                    }
                });


                MimeMessage msg = new MimeMessage(s);//multipurpose internet mail extension mime
                msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
                msg.addRecipient(Message.RecipientType.TO, new InternetAddress(userid));//here type recipient email id
                msg.setSubject("Order confirmation");

                msg.setContent(m, "text/html; charset=utf-8");
                Transport.send(msg);
                result = "success";


            } catch (Exception e) {
                e.printStackTrace();

            }
            result = "fail";
            return result;
        }
        @Override
        public void onProgressUpdate(Void... arg0) //optional
        {
            AlertDialog.Builder alert = new AlertDialog.Builder(OrderInvoice.this);
            alert.setTitle("Succcess");
            alert.setMessage("Order placed successfully and an confirmation email is sent to your emailid ");
            alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface obj, int x) {



                }
            });
            AlertDialog alertDialog = alert.create();
            alertDialog.show();

        }

        @Override
        public void onPostExecute(String result) //optional
        {





        }

        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }



    }
}
