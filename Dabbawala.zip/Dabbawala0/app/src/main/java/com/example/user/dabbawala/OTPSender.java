package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class OTPSender extends BroadcastReceiver {
    Context c;
    public OTPSender() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        try {



            DB_Conn50 obj=new DB_Conn50();
            obj.execute();

        }
        catch(Exception e){
            e.printStackTrace();
        }
        //throw new UnsupportedOperationException("Not yet implemented");


    }

    class DB_Conn50 extends AsyncTask<Void,Void,String>
    {


        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {
            String r="";

            try {

                Connection con = DB_Connection.get_DBConnection();

                PreparedStatement pst2 = con.prepareStatement("delete from dabbaotp");
                pst2.execute();
                pst2.close();

                PreparedStatement pst = con.prepareStatement("select * from dabbaorders where expiry >= now()");

                ResultSet rs=pst.executeQuery();
                if(rs.next())
                {
                    do{
                        Random r1 = new Random();
                        String otp = r1.nextInt(9) + "" + r1.nextInt(9) + "" + r1.nextInt(9) + "" + r1.nextInt(9);
                        Properties p = new Properties();
                        p.put("mail.smtp.starttls.enable", "true");//here smtp donot get start security gets started
                        p.put("mail.smtp.auth", "true");
                        p.put("mail.smtp.host", "173.194.202.108");
                        p.put("mail.smtp.port", "587");

                        Session s = Session.getDefaultInstance(p, new Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID, DB_Connection.SENDERS_PASSWORD);
                            }
                        });


                        MimeMessage msg = new MimeMessage(s);//multipurpose internet mail extension mime
                        msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
                        msg.addRecipient(Message.RecipientType.TO, new InternetAddress(rs.getString("userid")));//here type recipient email id
                        msg.setSubject("OTP for dabba delivery");
                        String m = "Greeting,<br/> Your OTP for dabba delivery is " + otp+"<br/>You need to share this with delivery person for delivery";
                        //msg.setText(m,"UTF-8","html");
                        msg.setContent(m, "text/html; charset=utf-8");
                        Transport.send(msg);

                        PreparedStatement pst1 = con.prepareStatement("insert into dabbaotp values(?,?,?,?)");
                        pst1.setString(1,rs.getString("oid"));
                        pst1.setString(2,rs.getString("userid"));
                        pst1.setString(3,new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
                        pst1.setString(4,otp);
                        pst1.execute();
                        pst1.close();


                    }
                    while(rs.next());


                }

                con.close();

                r = "success";



            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
                Toast.makeText(c,"success",Toast.LENGTH_SHORT).show();

            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(c);
                alert.setTitle("Error");
                alert.setMessage("Error occured");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {



                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}
