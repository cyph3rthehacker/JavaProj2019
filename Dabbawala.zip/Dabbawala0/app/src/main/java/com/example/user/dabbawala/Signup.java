package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Random;

import javax.mail.*;
import javax.mail.internet.*;


public class Signup extends AppCompatActivity {

    String fname, lname, emailid, mobile, password, confirmpassword, question, answer;
    int i=1;
    ProgressDialog pd;
    EditText txt_fname,txt_lname,txt_emailid,txt_mobile,txt_password,txt_confirmpassword, txt_question, txt_answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        txt_fname = (EditText) findViewById(R.id.txt_fname);
        txt_lname = (EditText) findViewById(R.id.txt_lname);
        txt_emailid = (EditText) findViewById(R.id.txt_emailid);
        txt_mobile = (EditText) findViewById(R.id.txt_name);
        txt_password = (EditText) findViewById(R.id.txt_password);
        txt_confirmpassword = (EditText) findViewById(R.id.txt_confirmpassword);
        txt_question = (EditText) findViewById(R.id.txt_question);
        txt_answer = (EditText) findViewById(R.id.txt_answer);

        txt_confirmpassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    if(!txt_confirmpassword.getText().toString().equals(txt_password.getText().toString()))
                    {
                        txt_confirmpassword.setError("Password and Confirm password do not match");
                        txt_confirmpassword.setText("");
                    }
                }
            }
        });

        Button b1 = (Button) findViewById(R.id.btn_register);

        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                fname = txt_fname.getText().toString();
                lname = txt_lname.getText().toString();
                emailid = txt_emailid.getText().toString();
                mobile = txt_mobile.getText().toString();
                password = txt_password.getText().toString();
                confirmpassword = txt_confirmpassword.getText().toString();
                question = txt_question.getText().toString();
                answer = txt_answer.getText().toString();


                if (fname.equals("") == false) {
                    if (lname.equals("") == false) {
                        if (emailid.equals("") == false && android.util.Patterns.EMAIL_ADDRESS.matcher(emailid).matches()) {
                            if (mobile.equals("") == false) {
                                if (password.equals("") == false) {
                                    if (confirmpassword.equals("") == false) {
                                        if (question.equals("") == false) {
                                            if (answer.equals("") == false) {

                                                DB_Conn obj = new DB_Conn();
                                                obj.execute(fname, lname, emailid, mobile, password, question, answer);

                                                pd = new ProgressDialog(Signup.this);
                                                pd.setMessage("Sending OTP on email..Please wait.."); // Setting Message
                                                pd.setTitle("Registration"); // Setting Title
                                                pd.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                                                pd.show(); // Display Progress Dialog
                                                pd.setCancelable(false);

                                            } else {
                                                txt_answer.setError("Please enter password");
                                            }
                                        } else {
                                            txt_question.setError("Please enter password");
                                        }
                                    } else {
                                        txt_confirmpassword.setError("Please enter password");
                                    }
                                } else {
                                    txt_password.setError("Please enter password");
                                }
                            } else {
                                txt_mobile.setError("Please enter mobile no");
                            }
                        } else {
                            txt_emailid.setError("Either emailid is blank or Invalid Format");
                        }
                    } else {
                        txt_lname.setError("Please enter last name");
                    }
                } else {
                    txt_fname.setError("Please enter first name");
                }

            }


        });
    }

    class DB_Conn extends AsyncTask<String, Void, String> {


        String otp = "",otpval="1111";
        String ar[] = new String[7];
        AlertDialog alertDialog;

        @Override
        public String doInBackground(String... arg) //compulsory to implement
        {
            String result = "";
            ar[0] = arg[0];
            ar[1] = arg[1];
            ar[2] = arg[2];
            ar[3] = arg[3];
            ar[4] = arg[4];
            ar[5] = arg[5];
            ar[6] = arg[6];
            try {
                Connection con = DB_Connection.get_DBConnection();
                PreparedStatement pst = con.prepareStatement("select * from login where userid=?");
                pst.setString(1, arg[2]);
                ResultSet rs = pst.executeQuery();

                if (rs.next() == false) {

                    Random r = new Random();
                    otp = r.nextInt(9) + "" + r.nextInt(9) + "" + r.nextInt(9) + "" + r.nextInt(9);
                    Properties p=new Properties();
                    p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                    p.put("mail.smtp.auth","true");
                    p.put("mail.smtp.host","173.194.202.108");
                    p.put("mail.smtp.port","587");

                    Session s= Session.getDefaultInstance(p,new Authenticator()
                    {
                        protected PasswordAuthentication getPasswordAuthentication()
                        {
                            return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                        }
                    });


                    MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                    msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
                    msg.addRecipient(Message.RecipientType.TO,new InternetAddress(emailid));//here type recipient email id
                    msg.setSubject("OTP for registration");
                    String m="Greeting,\n Your OTP for account activation is "+otp;
                    //msg.setText(m,"UTF-8","html");
                    msg.setContent(m, "text/html; charset=utf-8");
                    Transport.send(msg);


                    result = "success";
                } else {
                    result = "failed";
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        public void onProgressUpdate(Void... arg0) //optional
        {
                /*AlertDialog.Builder alert = new AlertDialog.Builder(Signup.this);

                LayoutInflater li = LayoutInflater.from(Signup.this);
                final View promptsView = li.inflate(R.layout.otp_alert,null);
                alert.setView(promptsView);
                alert.setPositiveButton("Validate", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {
                       otpval = ((EditText) promptsView.findViewById(R.id.txt_otp)).getText().toString();

                    }
                });

                AlertDialog alertDialog = alert.create();
                alertDialog.show();*/

        }

        @Override
        public void onPostExecute(String result) //optional
        {


            pd.dismiss();
            final AlertDialog.Builder alert = new AlertDialog.Builder(Signup.this);

            if (result.equals("success")) {
                i=1;
                alert.setTitle("OTP Validation");
                alert.setMessage(Html.fromHtml("An OTP has been sent to your emailid.<br/> Please check and enter the same.<font color=red> (max 3 attempts)</font>"));
                LayoutInflater li = LayoutInflater.from(Signup.this);
                final View promptsView = li.inflate(R.layout.otp_alert,null);
                alert.setView(promptsView);
                alert.setPositiveButton("Validate", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {


                        String otpval = ((EditText) promptsView.findViewById(R.id.txt_otp)).getText().toString();
                        if (otpval.equals(otp)) {
                            Runnable runnable = new Runnable() {
                                @Override
                                public void run() {
                                    insert();


                                }
                            };
                            Thread t = new Thread(runnable);
                            t.start();
                            Toast.makeText(Signup.this, "Registration successful.", Toast.LENGTH_SHORT).show();
                            Intent i=new Intent(Signup.this,Login.class);
                            startActivity(i);


                        } else {


                            if(i==3)
                            {
                                Toast.makeText(Signup.this, "Registration failed.", Toast.LENGTH_LONG).show();
                                txt_fname.setText("");
                                txt_lname.setText("");
                                txt_emailid.setText("");
                                txt_mobile.setText("");
                                txt_password.setText("");
                                txt_confirmpassword.setText("");
                                txt_question.setText("");
                                txt_answer.setText("");


                            }
                            else {
                                i++;
                                alert.setMessage(Html.fromHtml("Incorrect OTP entered.<br/>Please try again. <font color=red>("+(4-i)+" attempts left)</font>"));
                                ((EditText) promptsView.findViewById(R.id.txt_otp)).setText("");
                                ((ViewGroup) promptsView.getParent()).removeView(promptsView);

                                alert.show();
                            }
                        }


                    }
                });


            } else if (result.equals("failed")) {
                alert.setTitle("Error");
                alert.setMessage("This emailid is already registered. Try a different one");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {

                    }
                });
            }

            alertDialog = alert.create();
            alertDialog.show();


        }

        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

        public void insert()
        {
            try {

                Connection con = DB_Connection.get_DBConnection();

                PreparedStatement pst = con.prepareStatement("insert into users values(?,?,?,?,?,?)");
                pst.setString(1, ar[0]);
                pst.setString(2, ar[1]);
                pst.setString(3, ar[2]);
                pst.setString(4, ar[3]);
                pst.setString(5, ar[5]);
                pst.setString(6, ar[6]);

                pst.executeUpdate();

                pst = con.prepareStatement("insert into login values(?,?)");
                pst.setString(1, ar[2]);
                pst.setString(2, ar[4]);
                pst.executeUpdate();
                con.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }

    }


}



