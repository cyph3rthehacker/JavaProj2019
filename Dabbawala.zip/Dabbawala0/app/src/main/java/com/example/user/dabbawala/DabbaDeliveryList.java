package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class DabbaDeliveryList extends AppCompatActivity implements View.OnClickListener {

    ListView lv;

    ArrayList<HashMap<String,String>> arrayList;
    SimpleAdapter simpleAdapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dabba_delivery_list);

        lv = (ListView) findViewById(R.id.listView5);
        TextView t1=(TextView)findViewById(R.id.textView31);
        t1.setText("Showing dabba delivery list for: "+new SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date()));

        Button b1=(Button)findViewById(R.id.button13);
        b1.setOnClickListener(this);
        DB_Conn obj = new DB_Conn();
        obj.execute();

    }

    @Override
    public void onClick(View view) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.clear();
        ed.commit();

        Intent i=new Intent(this,Login.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    class DB_Conn extends AsyncTask<Void,Integer,String>
    {
        String[] from={"userid","edate","pick","drop","otp"};//string array
        int[] to={R.id.textView27,R.id.textView28,R.id.textView29,R.id.textView30,R.id.textView31};//int array of views id's

        @Override
        public String doInBackground(Void... arg) //compulsory to implement
        {
            arrayList=new ArrayList<>();
            String r="";

            try {

                Connection con=DB_Connection.get_DBConnection();

                PreparedStatement pst2 = con.prepareStatement("delete from dabbaotp");
                pst2.execute();
                pst2.close();

                PreparedStatement pst = con.prepareStatement("select * from dabbaorders where expiry >= now()");

                ResultSet rs=pst.executeQuery();
                if(rs.next()) {
                    do {
                        Random r1 = new Random();
                        String otp = r1.nextInt(9) + "" + r1.nextInt(9) + "" + r1.nextInt(9) + "" + r1.nextInt(9);
                        Properties p = new Properties();
                        p.put("mail.smtp.starttls.enable", "true");//here smtp donot get start security gets started
                        p.put("mail.smtp.auth", "true");
                        p.put("mail.smtp.host", "173.194.202.108");
                        p.put("mail.smtp.port", "587");

                        Session s = Session.getDefaultInstance(p, new Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID, DB_Connection.SENDERS_PASSWORD);
                            }
                        });


                        MimeMessage msg = new MimeMessage(s);//multipurpose internet mail extension mime
                        msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
                        msg.addRecipient(Message.RecipientType.TO, new InternetAddress(rs.getString("userid")));//here type recipient email id
                        msg.setSubject("OTP for dabba delivery");
                        String m = "Greeting,<br/> Your OTP for dabba delivery is " + otp + "<br/>You need to share this with delivery person for delivery";
                        //msg.setText(m,"UTF-8","html");
                        msg.setContent(m, "text/html; charset=utf-8");
                        Transport.send(msg);

                        PreparedStatement pst1 = con.prepareStatement("insert into dabbaotp values(?,?,?,?)");
                        pst1.setString(1, rs.getString("oid"));
                        pst1.setString(2, rs.getString("userid"));
                        pst1.setString(3, new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
                        pst1.setString(4, otp);
                        pst1.execute();
                        pst1.close();


                    }
                    while (rs.next());
                }


                pst.close();
                    pst = con.prepareStatement("select * from dabbaorders,dabbaotp where expiry >= now() and dabbaorders.oid=dabbaotp.oid");


                rs.close();
                 rs = pst.executeQuery();

                if (rs.next()) {

                    do {


                        HashMap<String,String> hashMap=new HashMap<>();//create a hashmap to store the data in key value pair

                        hashMap.put("userid","User ID: "+rs.getString("dabbaorders.userid"));
                        hashMap.put("edate","Expiry date: "+rs.getString("dabbaorders.expiry"));
                        hashMap.put("pick", "Pick up: "+rs.getString("dabbaorders.pick"));
                        hashMap.put("drop", "Drop: "+rs.getString("dabbaorders.drop1"));
                        hashMap.put("otp", "OTP: "+rs.getString("dabbaotp.otp"));


                        arrayList.add(hashMap);//add the hashmap into arrayList
                    }
                    while(rs.next());

                    r = "success";

                }
                else
                {
                    r="failure";
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Integer...arg0) //optional
        {


        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
                simpleAdapter1 = new SimpleAdapter(DabbaDeliveryList.this, arrayList, R.layout.dabbadeliverylist, from, to);//Create object and set the parameters for simpleAdapter
                lv.setAdapter(simpleAdapter1);//sets the adapter for listView
            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(DabbaDeliveryList.this);
                alert.setTitle("Error");
                alert.setMessage("No records found to display");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {

                        finish();
                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.icon, menu);
        return true;
    }
}