package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ForgotPassword extends AppCompatActivity implements View.OnClickListener {

    EditText txt_userid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        txt_userid=(EditText)findViewById(R.id.txt_userid);

        Button b1=(Button)findViewById(R.id.button2);
        b1.setOnClickListener(this);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {



        switch(item.getItemId()) {
            case R.id.home:


                    Intent i = new Intent(this, Login.class);
                    startActivity(i);

                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    public void onClick(View v)
    {
        String u=txt_userid.getText().toString().trim();

        if(u.equals("")==false && android.util.Patterns.EMAIL_ADDRESS.matcher(u).matches()) {

            DB_Conn obj = new DB_Conn();
            obj.execute(u);


        }
        else {
            txt_userid.setError("Either emailid is not entered or entered in invalid format");
        }
    }

    class DB_Conn extends AsyncTask<String,Void,String>
    {

        String u;
        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {
            String r="";
            try {

                Connection con=DB_Connection.get_DBConnection();

                PreparedStatement pst = con.prepareStatement("select * from login where userid=?");
                pst.setString(1, arg[0]);

                ResultSet rs = pst.executeQuery();
                if (rs.next() == true) {
                    u=arg[0];

                    r = "success";

                }
                else
                {
                    r="failure";
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
               /* sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = sp.edit();
                ed.putString("userid", u);
                ed.putBoolean("loggedin", true);

                ed.commit();*/
                String option = ((RadioButton) findViewById(((RadioGroup) findViewById(R.id.radioGroup)).getCheckedRadioButtonId())).getText().toString();

                Intent i=new Intent(ForgotPassword.this,ForgotPassword1.class);
                i.putExtra("userid",u);
                i.putExtra("option", option);

                startActivity(i);

                //Login.this.finish();
            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(ForgotPassword.this);
                alert.setTitle("Error");
                alert.setMessage("Entered userid does not exist");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {


                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}

