package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ResetPassword extends AppCompatActivity implements View.OnClickListener {

    EditText txt_new,txt_confirm;
    String u;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        Intent i=getIntent();
        u=i.getStringExtra("userid");

        txt_new =(EditText)findViewById(R.id.txt_newpassword);
        txt_confirm =(EditText)findViewById(R.id.txt_confirmpassword);

        Button b1=(Button)findViewById(R.id.button4);
        b1.setOnClickListener(this);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {



        switch(item.getItemId()) {
            case R.id.home:


                    Intent i = new Intent(this, Login.class);
                    startActivity(i);

                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    @Override
    public void onClick(View v) {

        String newpass=txt_new.getText().toString();
        String confirmpass=txt_confirm.getText().toString();

        if (newpass.equals("") == false) {
            if (confirmpass.equals("") == false) {
                if (confirmpass.equals(newpass) == true) {

                    Log.i("P",newpass);
                    Log.i("U",u);
                    DB_Conn obj = new DB_Conn();
                    obj.execute(u,newpass);
                }
                else {
                    txt_confirm.setError("Password and Confirm password do not match");
                }

            }
            else {
                txt_confirm.setError("Value is required");
            }
        }
        else {
            txt_new.setError("Value is required");
        }
    }

    class DB_Conn extends AsyncTask<String,Void,String>
    {


        @Override
        public String doInBackground(String...arg) //compulsory to implement
        {
            String r="";
            try {

                Connection con=DB_Connection.get_DBConnection();

                PreparedStatement pst = con.prepareStatement("update login set password=? where userid=?");
                pst.setString(1, arg[1]);
                pst.setString(2, arg[0]);
                pst.executeUpdate();
                r = "success";

                con.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
                /*sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = sp.edit();
                ed.putString("userid", u);
                ed.putBoolean("loggedin", true);

                ed.commit();

                //  Intent i=new Intent(Login.this,MainActivity_Admin.class);
                //startActivity(i);
                //Login.this.finish();*/
                AlertDialog.Builder alert = new AlertDialog.Builder(ResetPassword.this);
                alert.setTitle("Success");
                alert.setMessage("Password updated successfully");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {
                        Intent i = new Intent(ResetPassword.this, Login.class);
                        startActivity(i);

                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }

            else
            {

            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}


