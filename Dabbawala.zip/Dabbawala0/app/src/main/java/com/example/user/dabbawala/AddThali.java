package com.example.user.dabbawala;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

public class AddThali extends AppCompatActivity implements View.OnClickListener {

    EditText txt_id,txt_name,txt_desc,txt_price;
    String id,name,desc,price,type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_thali);
        DB_Conn1 obj1 = new DB_Conn1();
        obj1.execute();
        Button b1=(Button)findViewById(R.id.btn_ok);
        b1.setOnClickListener(this);
        txt_id=(EditText)findViewById(R.id.txt_tid);
        txt_name=(EditText)findViewById(R.id.txt_name);
        txt_desc=(EditText)findViewById(R.id.txt_desc);
        txt_price=(EditText)findViewById(R.id.txt_price);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the main_menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        SharedPreferences sp = getSharedPreferences("pf", Context.MODE_PRIVATE);

        String userid = sp.getString("userid", null);

        switch(item.getItemId()) {
            case R.id.home:
                if(userid.equals("admin@dabbawala.com")) {

                    Intent i = new Intent(this, MainPage_Admin.class);
                    startActivity(i);
                }
                else{
                    Intent i = new Intent(this, MainPage.class);
                    startActivity(i);
                }
                break;

            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }
    public void onClick(View v)
    {
        id=txt_id.getText().toString();
        name=txt_name.getText().toString();
        desc=txt_desc.getText().toString();
        price=txt_price.getText().toString();
        type=((RadioButton)findViewById(((RadioGroup)findViewById(R.id.rg)).getCheckedRadioButtonId())).getText().toString();
        if (name.equals("") == false) {
            if (desc.equals("") == false) {
                if (price.equals("") == false && Integer.parseInt(price)>0) {

                            DB_Conn obj = new DB_Conn();
                            obj.execute();
                }
                else {
                    txt_price.setError("Either price is blank or Invalid value");
                }
            } else {
                txt_desc.setError("Value is required");
            }
        } else{
            txt_name.setError("Value is required");
        }

    }
    class DB_Conn extends AsyncTask<Void,Void,String>
    {


        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {
            String r="";

            try {

                Connection con=DB_Connection.get_DBConnection();

                PreparedStatement pst = con.prepareStatement("insert into thali values(?,?,?,?,?)");
                pst.setString(1, id);
                pst.setString(2, name);
                pst.setInt(3, Integer.parseInt(price));
                pst.setString(4, desc);
                pst.setString(5, type);

                pst.execute();
                con.close();
                r = "success";



            } catch (Exception e) {
                e.printStackTrace();
            }
            return r;
        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            if(result.equals("success"))
            {
                /*sp = getSharedPreferences("pf", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = sp.edit();
                ed.putString("userid", u);
                ed.putBoolean("loggedin", true);

                ed.commit();*/
                AlertDialog.Builder alert = new AlertDialog.Builder(AddThali.this);
                alert.setTitle("Success");
                alert.setMessage("Thali added successfully");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {
                        txt_id.setText("");
                        txt_name.setText("");
                        txt_desc.setText("");
                        txt_price.setText("");

                        DB_Conn1 obj1 = new DB_Conn1();
                        obj1.execute();

                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();

            }

            else
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(AddThali.this);
                alert.setTitle("Error");
                alert.setMessage("Error occured");
                alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface obj, int x) {



                    }
                });
                AlertDialog alertDialog = alert.create();
                alertDialog.show();
            }
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }


    class DB_Conn1 extends AsyncTask<Void,Void,String>
    {
        String tid="";

        @Override
        public String doInBackground(Void...arg) //compulsory to implement
        {

            try {

                Connection con=DB_Connection.get_DBConnection();

                Calendar cl=Calendar.getInstance();

                PreparedStatement pst=con.prepareStatement("select max(tid) from thali");
                ResultSet rs=pst.executeQuery();
                rs.next();
                String v=rs.getString(1);
                if(v!=null)
                {
                    if(String.valueOf(cl.get(Calendar.YEAR)).equals(v.substring(1,5)))
                    {
                        int v1=Integer.parseInt(v.substring(v.length()-5));
                        v1=v1+1;
                        tid="T"+cl.get(Calendar.YEAR)+String.format("%05d",v1);
                    }
                    else
                    {
                        tid="T"+cl.get(Calendar.YEAR)+"00001";
                    }
                }
                else
                {

                    tid="T"+cl.get(Calendar.YEAR)+"00001";
                }
                pst.close();



            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }
        @Override
        public void onProgressUpdate(Void...arg0) //optional
        {

        }
        @Override
        public void onPostExecute(String result) //optional
        {
            //  do something after execution
            ((EditText)findViewById(R.id.txt_tid)).setText(tid);
        }


        @Override
        public void onPreExecute() //optional
        {
            // do something before start
        }

    }
}
