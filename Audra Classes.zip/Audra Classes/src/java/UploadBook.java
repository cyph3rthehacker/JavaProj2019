import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;
import java.util.*;
import javax.servlet.annotation.MultipartConfig;

@MultipartConfig
public class UploadBook extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        InputStream is=null;
       

        HttpSession hs=req.getSession(false);
        
        String values="";
        try
        {       
            Collection<Part> p= req.getParts();
            Iterator i=p.iterator();
            while(i.hasNext())
            {
                 Part p1=(Part)i.next();
                
                 if(p1.getName().equalsIgnoreCase("txtfile"))
                 {
                    is= p1.getInputStream();
                   
                 }
                 else
                 {
                    InputStream i1= p1.getInputStream();
                    int ch;
                    StringBuilder sb = new StringBuilder();
                    while((ch = i1.read()) != -1)
                    {
                        sb.append((char)ch);
                    }
                    values=sb.toString();
                   
                 }
            }
            Connection con=DB_Connection.get_DBConnection();
            PreparedStatement pst1=con.prepareStatement("insert into books_pdf values(?,?)");

            pst1.setString(1, values);
            pst1.setBlob(2, is);           
            pst1.executeUpdate();
            req.setAttribute("msg", "$('#modal-msg').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("uploadbook.jsp");
            rd.forward(req, res);
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
}