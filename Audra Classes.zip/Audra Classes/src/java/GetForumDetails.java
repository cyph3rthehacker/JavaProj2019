import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class GetForumDetails extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        try
        {
        Connection con=DB_Connection.get_DBConnection();   
        
        res.setContentType("text/html");
        HttpSession hs=req.getSession(false);
        PreparedStatement pst2;
        String id=req.getParameter("id");
        String n="";
        String t="";
        
        pst2=con.prepareStatement("select * from question where question.id=?");
        pst2.setString(1, id);
        ResultSet rs1=pst2.executeQuery(); 
        rs1.next();
        String q=rs1.getString("question");
        t=t+"<div class='col-md-6' style=color:white;';font-weight:bold;font-size:20px'>"+q+"</div>";
        t=t+"<div class='col-md-8 col-md-offset-6' >"+rs1.getString("userid")+" ("+rs1.getString("date")+")</div>";
        t=t+"<br/><br/><hr></hr>";
        
        pst2=con.prepareStatement("select * from question_answer where id=?");
        pst2.setString(1, id);
        rs1=pst2.executeQuery();            

        
        if(rs1.next())
        {
            do
            {               
            t=t+"<span style='font-weight:bold;padding-bottom:100px'>"+rs1.getString("userid")+" ("+rs1.getString("date")+")</span>";
            t=t+"<div class='well'>";
            
            t=t+rs1.getString("answer");              
           
            t=t+"</div>";
            }
            while(rs1.next());
            
        }
         t=t+"<input type='hidden' id='h1' value='"+id+"'>";
         pw.println(t);
        
       }    
         
        catch(Exception e)
        {
            pw.println(e);
        }   
        
    }
}