import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import p1.*;


public class NewQuestion extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        String pcode="";
        try
        {
        
        String f=req.getParameter("txtquestion").trim();
              
        Connection con=DB_Connection.get_DBConnection();
        Calendar cl=Calendar.getInstance();
        PreparedStatement pst=con.prepareStatement("select max(id) from question");
        ResultSet rs=pst.executeQuery();
        rs.next();
        String v=rs.getString(1);
        if(v!=null)
        {
                if(String.valueOf(cl.get(Calendar.YEAR)).equals(v.substring(1,5)))
                {
                        int v1=Integer.parseInt(v.substring(v.length()-5));
                        v1=v1+1;
                        pcode="Q"+cl.get(Calendar.YEAR)+String.format("%05d",v1);
                }
                else
                {
                        pcode="Q"+cl.get(Calendar.YEAR)+"00001";
                }
        }
        else
        {
                pcode="Q"+cl.get(Calendar.YEAR)+"00001";
        }
            
        PreparedStatement pst1=con.prepareStatement("insert into question values(?,?,?,?)");
        pst1.setString(1,pcode);
        pst1.setString(2,req.getSession(false).getAttribute("A1").toString());
        pst1.setString(3,f);
        pst1.setString(4,new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
        

            pst1.executeUpdate();
            pst.close();

            req.setAttribute("msg", "$('#modal-msg').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("newquestion.jsp");
            rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}