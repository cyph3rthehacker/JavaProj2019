import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;

import p1.*;



public class DownloadBook extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        //PrintWriter pw=res.getWriter();
        
       String name=req.getParameter("h1");
        try
        {
            Connection con=DB_Connection.get_DBConnection();
            
           
            
            PreparedStatement ps = con.prepareStatement("select * from books_pdf where name=?");
            ps.setString(1, name);
            ResultSet rs=ps.executeQuery();
            rs.next();
            byte []fileBytes = rs.getBytes("pdffile");
            
            OutputStream targetFile=  res.getOutputStream();
            res.setContentType("application/x-download");
            res.setHeader("Content-Disposition", "attachment; filename=" + rs.getString("name")+".pdf");
            targetFile.write(fileBytes);
            targetFile.close();
           
            
           
           
           
        }
        catch(Exception e)
        {
           // pw.println(e);
        }
    }
        
}