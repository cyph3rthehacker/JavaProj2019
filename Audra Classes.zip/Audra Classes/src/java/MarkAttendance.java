import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import p1.*;


public class MarkAttendance extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        String c=req.getParameter("h1").trim();
        
        
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst11;
        
        Enumeration en=req.getParameterNames();
        
        while(en.hasMoreElements())
        {
                Object o=en.nextElement();

                String sid=o.toString();

                String v=req.getParameter(sid);
                if(sid.charAt(0)=='S')
                {
                    pst11=con.prepareStatement("insert into attendance values(?,?,?,?)");
                    pst11.setString(1, sid);//code
                    pst11.setString(2,new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
                    pst11.setString(3, c);//code
                    pst11.setString(4,v);//age
                    pst11.execute();
                }

                

        }     
      
            req.setAttribute("msg", "$('#modal-msg1').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("selectclass_attendance.jsp");
            rd.forward(req, res); 
       
        }
        catch(Exception e)
        {
            pw.println(e);
           
        }

              
        
    }
}