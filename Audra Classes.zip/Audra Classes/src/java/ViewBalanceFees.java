import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import p1.*;


public class ViewBalanceFees extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        HttpSession hs=req.getSession(false);
      

        try
        {
         
       
            Connection con=DB_Connection.get_DBConnection();
        
       
            PreparedStatement pst2=con.prepareStatement("select * from students where bal>?");
            //pst2.setString(1,new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
            pst2.setInt(1,0);
            ResultSet rs1=pst2.executeQuery();
           
            String t="";
           
            if(rs1.next())
            {
                
                do
                {
                   
               
                
               
                t=t+"<tr class='info'>";
                t=t+"<td>"+rs1.getString("sid");
                t=t+"<td>"+rs1.getString("name");
                t=t+"<td>"+rs1.getString("emailid");
                t=t+"<td>"+rs1.getString("class");                
                t=t+"<td>"+rs1.getString("fees");
                t=t+"<td>"+(rs1.getInt("fees")-rs1.getInt("bal"));
                t=t+"<td>"+rs1.getString("bal");
               
                
                
                t=t+"<td style='padding-left:40px '>"+"<button id='btn_delete' type='button' class='fa fa-envelope-square' style='border:none;font-size:20px;color:#ff3333;background-color: #d9edf7;'></i></button></tr>";
                
               
                }
                while(rs1.next());
                pw.println(t);
            }
            else
            {
                
           pw.println("<p style='font-weight:bolder;color:red;font-size:20px'><i style='font-weight:bolder;color:red;font-size:25px' class='fa fa-smile-o'></i> Hurray.....!!!! No fees pending</style> ");

            }
                

        
       
       
      
        
       }    
         
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}