
import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;

 public class GetProfilePic extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
         //PrintWriter pw=res.getWriter();
         res.setContentType("image/jpeg");
         HttpSession hs=req.getSession(false);
         byte b[]=null;
        try
        {
      
     /*  String n=req.getParameter(nm);*/
              
        Connection con=DB_Connection.get_DBConnection();
        if(hs.getAttribute("A2").toString().equals("teacher"))
        {
            PreparedStatement pst1=con.prepareStatement("Select * from teachers where emailid=?");
            pst1.setString(1, hs.getAttribute("A1").toString());
            ResultSet rs=pst1.executeQuery();
            rs.next();

            if(rs.getBytes("pic")!=null)
            {
                b=rs.getBytes("pic");
                ServletOutputStream o=res.getOutputStream();
                o.write(b);
                o.flush();
                o.close();
            }
        }
        else
        {
            PreparedStatement pst1=con.prepareStatement("Select * from students where emailid=?");
            pst1.setString(1, hs.getAttribute("A1").toString());
            ResultSet rs=pst1.executeQuery();
            rs.next();

            if(rs.getBytes("pic")!=null)
            {
                b=rs.getBytes("pic");
                ServletOutputStream o=res.getOutputStream();
                o.write(b);
                o.flush();
                o.close();
            }
        }
        
        
     
        }
        catch(Exception e)
        {
           
        }
    }
        
}