import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class GetBooks extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        HttpSession hs=req.getSession(false);
        String status=req.getParameter("status");

        try
        {
 
            Connection con=DB_Connection.get_DBConnection();
            ResultSet rs1;
           
            PreparedStatement pst2=con.prepareStatement("select * from books_pdf");

            rs1=pst2.executeQuery();
            
            
            String t="";
            int i=1;
            if(rs1.next())
            {
                
                do
                {
                   

                t=t+"<tr class='info'>";
                t=t+"<td>"+rs1.getString(1);              
                                
                
                t=t+"<td style='padding-left:20px'>"+"<a href=DownloadBook?h1="+rs1.getString(1)+" class='btn btn-primary'>Download</a></form></tr>";
                
                i++;
                }
                while(rs1.next());
                 pw.println(t);
            }
            else
            {
                
           pw.println("<p style='font-weight:bolder;color:green;font-size:20px'><i style='font-weight:bolder;color:green;font-size:25px' class='fa fa-smile-o'></i> No Books available </style> ");

            }
        
       }    
         
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}