import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;


public class SendEmail extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        
        String cname=req.getParameter("cname");
        String emailid=req.getParameter("emailid");
        String bal=req.getParameter("bal");
        String duedate=req.getParameter("duedate");
        String t="Course: "+cname+"<br>Balance: "+bal+"<br>Due date: "+duedate;
        try
        {
       
            Connection con=DB_Connection.get_DBConnection();
          
            
            Properties p=new Properties();
            p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
            p.put("mail.smtp.auth","true");
            p.put("mail.smtp.host","smtp.gmail.com");
            p.put("mail.smtp.port","587");

            Session s= Session.getInstance(p,new Authenticator()
            {
                    protected PasswordAuthentication getPasswordAuthentication() 
                    {
                            return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                    }	
            });

            MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
            msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
            msg.addRecipient(Message.RecipientType.TO,new InternetAddress(emailid));//here type recipient email id
            msg.setSubject("Balance Fees payment reminder");
            String m="<h3><br>Your due date for payment of balance fees has crossed.<br/>Following are the details of balance fees:<br/><br/>"+t+"<br/>Please consider payment of balance at the earliest";
            msg.setText(m,"UTF-8","html");
            Transport.send(msg);
      
           
       
        
            RequestDispatcher rd=req.getRequestDispatcher("ViewBalanceFees");
            rd.forward(req,res);
         
           
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}