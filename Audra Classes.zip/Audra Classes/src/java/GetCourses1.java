
import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;

 public class GetCourses1 extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
       PrintWriter pw=res.getWriter();
        
        try
        {      
     
         String n=req.getParameter("n")    ;
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst1=con.prepareStatement("Select cname from student_course where sid=? and balance>0");
        pst1.setString(1, n);
        ResultSet rs=pst1.executeQuery();
        String p="";
        while(rs.next())
        {
            p=p+"-"+rs.getString(1);
          
        }
        pw.println(p);
        
     
        }
        catch(Exception e)
        {
           
        }
    }
        
}