import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;


public class DeleteClass extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        String sid=req.getParameter("sid");
        try
        {
       
            Connection con=DB_Connection.get_DBConnection();
            
            PreparedStatement pst=con.prepareStatement("delete from class where cname=?");
            pst.setString(1,sid);
            pst.executeUpdate();
            pst.close();
      
            RequestDispatcher rd=req.getRequestDispatcher("ViewClass");
            rd.forward(req,res);
         
           
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}