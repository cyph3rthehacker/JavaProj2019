import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class CourseDetails extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        HttpSession hs=req.getSession(false);
      

        try
        {
            String sid=req.getParameter("sid");
            
             Connection con=DB_Connection.get_DBConnection();
        
             PreparedStatement pst2=con.prepareStatement("select * from student_course where sid=?");
             pst2.setString(1, sid);
             ResultSet rs1=pst2.executeQuery();
            
           
            String t="";
            int i=1;
            if(rs1.next())
            {                
                do
                {
                t=t+"<tr class='info'>";
                
                t=t+"<td>"+rs1.getString(2);
                t=t+"<td>"+rs1.getString(3);
                t=t+"<td>"+rs1.getString(4);
                t=t+"<td>"+rs1.getString(5);
                t=t+"<td>"+rs1.getString(6);
                t=t+"<td><a style='cursor:pointer' data-toggle='collapse' data-target='#demo"+i+"'>Payment Details</a></td>";

                
                t=t+"</tr>";
                String t1="";
                PreparedStatement pst3=con.prepareStatement("select * from student_payment where sid=? and cname=?");
                pst3.setString(1, sid);
                pst3.setString(2, rs1.getString(2));
                ResultSet rs2=pst3.executeQuery();
                
                while(rs2.next())
                {
                t1=t1+"<br/><b>Payment Date:</b> "+rs2.getString(3)+"<span style='padding-right:5px'></span>";
                t1=t1+"<b>Amt:</b> "+rs2.getString(4)+"<span style='padding-right:5px'></span>";
                t1=t1+"<b>Mode:</b> "+rs2.getString(5)+"/-<span style='padding-right:5px'></span>";
                t1=t1+"<b>Due Date:</b> "+rs2.getString(6)+"/-";
                }
               
                t=t+"<td colspan='4'><div id='demo"+i+"' class='collapse'>"+t1+"</div></td>";
                i++;        
               
                }
                while(rs1.next());
                pw.println(t);
            }
            else
            {
                
            pw.println("<p style='font-weight:bolder;color:green;font-size:20px'><i style='font-weight:bolder;color:red;font-size:25px' class='fa fa-frown-o'></i> Oopsss....No Courses to Display </style> ");

            }
          
       }    
         
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}