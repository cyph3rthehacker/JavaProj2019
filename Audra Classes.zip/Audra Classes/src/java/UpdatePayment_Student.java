import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import p1.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class UpdatePayment_Student extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        int amt=Integer.parseInt(req.getParameter("tamt").trim());               
        int bal=Integer.parseInt(req.getParameter("txtnewbalance").trim());   
        
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement pst1=con.prepareStatement("Select sid,emailid,class from students where emailid=?");
        pst1.setString(1,req.getSession(false).getAttribute("A1").toString());
       
        ResultSet rs=pst1.executeQuery();
        rs.next();
        String e=rs.getString("emailid");
        
        pst1=con.prepareStatement("update students set bal=bal-? where sid=?");
        pst1.setInt(1, amt);
        pst1.setString(2, rs.getString("sid"));        
       
        pst1.execute();
        
        pst1=con.prepareStatement("insert into student_payment values(?,?,?,?)");
        pst1.setString(1, rs.getString("sid"));
        pst1.setString(2, new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
        pst1.setInt(3,amt);
        pst1.setString(4,"Card");
        
        pst1.execute();
        String t="Class: "+rs.getString("class") +"<br>Fees paid: "+amt+"<br>Balance: "+bal+"<br>Payment mode: Card";
        Properties p=new Properties();
        p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
        p.put("mail.smtp.auth","true");
        p.put("mail.smtp.host","smtp.gmail.com");
        p.put("mail.smtp.port","587");

        Session s= Session.getInstance(p,new Authenticator()
        {
                protected PasswordAuthentication getPasswordAuthentication() 
                {
                        return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                }	
        });

        MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
        msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
        msg.addRecipient(Message.RecipientType.TO,new InternetAddress(e));//here type recipient email id
        msg.setSubject("Payment Confirmation");
        String m="<h3>We thank you for making the payment.</h3><br>Following are the details:<br/><br/>"+t;
        msg.setText(m,"UTF-8","html");
        Transport.send(msg);


        req.setAttribute("msg", "$('#modal-msg').modal('show');");
        RequestDispatcher rd=req.getRequestDispatcher("makepayment.jsp");
        rd.forward(req, res);
                      
       
        }
        catch(Exception e)
        {
            pw.println(e);
           
        }

              
        
    }
}