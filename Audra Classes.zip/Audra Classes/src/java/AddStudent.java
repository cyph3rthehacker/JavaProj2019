import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;
import p1.*;
import javax.servlet.annotation.MultipartConfig;

@MultipartConfig
public class AddStudent extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        InputStream is[];
        is=new InputStream[]{null};
        String values[]=new String[10];
        int j=0;
        try
        {
            Collection<Part> p= req.getParts();
            Iterator i=p.iterator();
            while(i.hasNext())
            {
                 Part p1=(Part)i.next();
                
                 if(p1.getName().equalsIgnoreCase("txtpic"))
                 {
                    is[0]= p1.getInputStream();
                   
                 }
                 else
                 {
                    InputStream i1= p1.getInputStream();
                    int ch;
                    StringBuilder sb = new StringBuilder();
                    while((ch = i1.read()) != -1)
                    {
                        sb.append((char)ch);
                    }
                    values[j]=sb.toString();
                    j++;
                 }
            }          
        
       
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement pst11=con.prepareStatement("select * from login where userid=?");
        pst11.setString(1, values[6]);//code
        ResultSet rs=pst11.executeQuery();
        
        if(rs.next()==false)
        {
        
            PreparedStatement pst1=con.prepareStatement("insert into students values(?,?,?,?,?,?,?,?,?,?,?,?)");
            pst1.setString(1, values[0]);//code
            pst1.setString(2, values[1]);//name
            pst1.setInt(3, Integer.parseInt(values[2]));//age
            pst1.setString(4, values[3]);//gender
            pst1.setString(5,values[4]);//addr
            pst1.setString(6, values[5]);//mobile
            pst1.setString(7, values[6]);//email
            pst1.setString(8, values[7]);//email
            pst1.setString(9, values[8]);//class
            pst1.setInt(10, Integer.parseInt(values[9]));//class
            pst1.setInt(11, Integer.parseInt(values[9]));//class
            pst1.setBlob(12, is[0]);//pic
            
            pst1.executeUpdate();

            pst1=con.prepareStatement("insert into login values(?,?,?)");
            pst1.setString(1, values[6]);//code
            pst1.setString(2, values[1]);//name
            pst1.setString(3, "student");//name
            
           
            pst1.executeUpdate();



            req.setAttribute("msg", "$('#modal-msg').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("addstudent.jsp");
            rd.forward(req, res);
        }
        else
        {
            req.setAttribute("msg1", "$('#modal-msg1').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("addstudent.jsp");
            rd.forward(req, res);
        }
            
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}