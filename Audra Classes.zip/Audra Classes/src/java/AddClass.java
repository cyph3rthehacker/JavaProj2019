import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class AddClass extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        String cname=req.getParameter("txtcname").trim();
        int fees=Integer.parseInt(req.getParameter("txtfees").trim());
        
       
      
        
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst1=con.prepareStatement("select * from class where cname=?");
        pst1.setString(1, cname);
       
        ResultSet rs=pst1.executeQuery();
        
        if(rs.next()==false)
        {         
            PreparedStatement pst11=con.prepareStatement("insert into class values(?,?)");
            pst11.setString(1, cname);//code
            pst11.setInt(2,fees);//age
            pst11.execute();


            req.setAttribute("msg", "$('#modal-msg').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("addclass.jsp");
            rd.forward(req, res);
                      
        }
        else
        {
           
            req.setAttribute("msg1", "$('#modal-msg1').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("addclass.jsp");
            rd.forward(req, res); 
        }
        }
        catch(Exception e)
        {
            pw.println(e);
           
        }

              
        
    }
}