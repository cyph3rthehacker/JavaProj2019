import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import p1.*;


public class AddAns extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        HttpSession hs=req.getSession(false);
        String comment=req.getParameter("txtcomment").trim();
        String pcode=req.getParameter("id").trim();
        
        Connection con=DB_Connection.get_DBConnection();
        
              
        PreparedStatement pst1=con.prepareStatement("insert into question_answer values(?,?,?,?)");
        pst1.setString(1,pcode);
        pst1.setString(2,hs.getAttribute("A1").toString());
        pst1.setString(3,comment);
        pst1.setString(4,new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
        pst1.executeUpdate();
        
        //req.setAttribute("id", pcode);
       // RequestDispatcher rd=req.getRequestDispatcher("ViewStudents");
        //rd.forward(req,res);
        
       

        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}