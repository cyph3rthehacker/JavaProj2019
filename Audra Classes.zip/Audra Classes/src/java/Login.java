import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;

public class Login extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
                
        try
        {
        String u=req.getParameter("txtuserid");
        String p=req.getParameter("txtpassword");
        Connection con=DB_Connection.get_DBConnection();
        
            PreparedStatement pst=con.prepareStatement("select * from login where userid=? and password=?");
            pst.setString(1,u);
            pst.setString(2,p);
            ResultSet rs=pst.executeQuery();
            if(rs.next())
            {
                HttpSession hs=req.getSession(true);
            if(rs.getString("type").equalsIgnoreCase("admin"))
            {
                    hs.setAttribute("A1", u);
                    hs.setAttribute("A2",rs.getString("type")); 
            }
            else if(rs.getString("type").equalsIgnoreCase("teacher"))
            {
                PreparedStatement pst1=con.prepareStatement("select * from teachers where emailid=?");
                pst1.setString(1,u);              
                ResultSet rs1=pst1.executeQuery();
                rs1.next();
                hs.setAttribute("A1", u);
                hs.setAttribute("A2", rs1.getString(2));
                hs.setAttribute("A3", "teacher");
                
            }
            else if(rs.getString("type").equalsIgnoreCase("student"))
            {
                PreparedStatement pst1=con.prepareStatement("select * from students where emailid=?");
                pst1.setString(1,u);
                ResultSet rs1=pst1.executeQuery();
                rs1.next();
                hs.setAttribute("A1", u);
                hs.setAttribute("A2", rs1.getString(2));
                hs.setAttribute("A3", "student");
            }

                    res.sendRedirect("home.jsp");

            }
            else
            {
           
            
            req.setAttribute("msg", "$('#modal-msg').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("home.jsp");
            rd.forward(req, res);
                         
            }
       
        }
        catch(Exception e)
        {
            pw.println(e);
        }
        
    }
}