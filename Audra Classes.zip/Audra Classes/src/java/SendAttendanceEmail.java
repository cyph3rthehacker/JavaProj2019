import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;


public class SendAttendanceEmail extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        
        String limit=req.getParameter("txtlimit");
        String c=req.getParameter("c");
        String m=req.getParameter("m").trim();
        String y=req.getParameter("y").trim();
        
        try
        {
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                p.put("mail.smtp.auth","true");
                p.put("mail.smtp.host","smtp.gmail.com");
                p.put("mail.smtp.port","587");

                Session s= Session.getInstance(p,new Authenticator()
                {
                        protected PasswordAuthentication getPasswordAuthentication() 
                        {
                                return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                        }	
                });

                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
                Connection con=DB_Connection.get_DBConnection();
          
             PreparedStatement pst = con.prepareStatement("select count(*) from attendance where class=? and year(attendancedate)=? and date_format(attendancedate,'%m')=? group by sid order by 1 desc");
             pst.setString(1, c);
             pst.setString(2, y);
             pst.setString(3, m);
             ResultSet rs = pst.executeQuery();
             if(rs.next())
             {
                int total=rs.getInt(1);

                PreparedStatement pst1 = con.prepareStatement("select sid, name,emailid,pemailid from students where class=? order by sid");
                pst1.setString(1, c);
                rs = pst1.executeQuery();

                String t="";
                while(rs.next())
                {
                    pst = con.prepareStatement("select count(sid) from attendance where class=? and year(attendancedate)=? and date_format(attendancedate,'%m')=? and status=? and sid=?");
                    pst.setString(1, c);
                    pst.setString(2, y);
                    pst.setString(3, m);
                    pst.setString(4, "p");
                    pst.setString(5, rs.getString(1));
                    ResultSet rs1 = pst.executeQuery();
                    rs1.next();
                    int p1=(rs1.getInt(1)*100)/total;
                    if(p1<Integer.parseInt(limit))
                    {    
                        msg.addRecipient(Message.RecipientType.TO,new InternetAddress(rs.getString("pemailid")));//here type recipient email id
                        msg.setSubject("Attendance Shortfall");
                        String m1="<h3><br>This is to inform you that attendance for your ward is short.<br/>Following are the details<br/><br/>Month/Year: "+m+"/"+y+"<br/>Attendance %: "+p1;
                        msg.setText(m,"UTF-8","html");
                        Transport.send(msg);
                    }
      
           
                }
                 req.setAttribute("msg2", "$('#modal-msg2').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("selectclass_attendance.jsp");
            rd.forward(req,res);
         
           
            }
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}