import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;
import javax.servlet.annotation.MultipartConfig;

@MultipartConfig
public class UploadPic extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        
        
        HttpSession hs=req.getSession(false);
        try
        {
          Part p1 = req.getPart("txtpic");
          InputStream is=p1.getInputStream();              
                 
            
        
        Connection con=DB_Connection.get_DBConnection();
     
        if(hs.getAttribute("A2").toString().equals("teacher"))
        {
            PreparedStatement pst=con.prepareStatement("update teachers set pic=? where emailid=?");
            pst.setBlob(1, is);
            pst.setString(2, hs.getAttribute("A1").toString());
            pst.executeUpdate();
            pst.close();

            req.setAttribute("msg","$('#modal-msg').modal('show');");

            RequestDispatcher rd=req.getRequestDispatcher("uploadpic.jsp");
            rd.forward(req, res);
        }
        else
        {
            PreparedStatement pst=con.prepareStatement("update students set pic=? where emailid=?");
            pst.setBlob(1, is);
            pst.setString(2, hs.getAttribute("A1").toString());
            pst.executeUpdate();
            pst.close();

            req.setAttribute("msg","$('#modal-msg').modal('show');");

            RequestDispatcher rd=req.getRequestDispatcher("uploadpic.jsp");
            rd.forward(req, res);
        }
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}