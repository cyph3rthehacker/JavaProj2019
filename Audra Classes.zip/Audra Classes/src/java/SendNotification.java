import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class SendNotification extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        String m=req.getParameter("txtmsg").trim();
        String c=req.getParameter("txtclass").trim();
        
        
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst1=con.prepareStatement("select * from students where class=?");
        pst1.setString(1, c);
        ResultSet rs=pst1.executeQuery();
        
        if(rs.next())
        {         
            
            do{                
            
            Properties p=new Properties();
            p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
            p.put("mail.smtp.auth","true");
            p.put("mail.smtp.host","smtp.gmail.com");
            p.put("mail.smtp.port","587");

            Session s= Session.getInstance(p,new Authenticator()
            {
                    protected PasswordAuthentication getPasswordAuthentication() 
                    {
                                   return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                    }
            });


            MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
            msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
            msg.addRecipient(Message.RecipientType.TO,new InternetAddress(rs.getString("emailid")));//here type recipient email id
            msg.setSubject("Notification/Message");
            
            msg.setContent(m, "text/html; charset=utf-8");
            Transport.send(msg);
            }
            while(rs.next());

           
            req.setAttribute("msg", "$('#modal-msg').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("sendnotification.jsp");
            rd.forward(req, res);
                      
        }
        else
        {
           
            req.setAttribute("msg1", "$('#modal-msg1').modal('show');");
            RequestDispatcher rd=req.getRequestDispatcher("sendnotification.jsp");
            rd.forward(req, res);
        }
        }
        catch(Exception e)
        {
            pw.println(e);
           
        }

              
        
    }
}