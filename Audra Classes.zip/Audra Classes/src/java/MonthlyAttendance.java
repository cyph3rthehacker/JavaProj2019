import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class MonthlyAttendance extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        HttpSession hs=req.getSession(false);
      

        try
        {
         
            String c=req.getParameter("txtclass").trim();
            String m=req.getParameter("select_month").trim();
            String y=req.getParameter("select_year").trim();
            
            Connection con=DB_Connection.get_DBConnection();
        
             PreparedStatement pst = con.prepareStatement("select count(*) from attendance where class=? and year(attendancedate)=? and date_format(attendancedate,'%m')=? group by sid order by 1 desc");
             pst.setString(1, c);
             pst.setString(2, y);
             pst.setString(3, m);
             ResultSet rs = pst.executeQuery();
             if(rs.next())
             {
                int total=rs.getInt(1);

                PreparedStatement pst1 = con.prepareStatement("select sid, name,emailid from students where class=? order by sid");
                pst1.setString(1, c);
                rs = pst1.executeQuery();

                String t="";
                while(rs.next())
                {
                    pst = con.prepareStatement("select count(sid) from attendance where class=? and year(attendancedate)=? and date_format(attendancedate,'%m')=? and status=? and sid=?");
                    pst.setString(1, c);
                    pst.setString(2, y);
                    pst.setString(3, m);
                    pst.setString(4, "p");
                    pst.setString(5, rs.getString(1));
                    ResultSet rs1 = pst.executeQuery();
                    rs1.next();
                    int p=(rs1.getInt(1)*100)/total;


                    t=t+"<tr class='info'>";
                    t=t+"<td>"+rs.getString("sid");
                    t=t+"<td>"+rs.getString("name");
                    t=t+"<td>"+rs1.getInt(1);
                    t=t+"<td>"+p;

                }
                req.setAttribute("m", t);
                req.setAttribute("c", c);
                req.setAttribute("month", m);
                req.setAttribute("year", y);
                req.setAttribute("my", m+"/"+y);
                req.setAttribute("total", total);
                RequestDispatcher rd=req.getRequestDispatcher("displaymonthlyattendance.jsp");
                rd.forward(req, res); 
                
             }
             else
             {
                req.setAttribute("msg1", "$('#modal-msg1').modal('show');");
                RequestDispatcher rd=req.getRequestDispatcher("monthly_attendance.jsp");
                rd.forward(req, res); 
             }
            
          
       }    
         
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}

/*
 * else
            {
                
            pw.println("<p style='font-weight:bolder;color:green;font-size:20px'><i style='font-weight:bolder;color:red;font-size:25px' class='fa fa-frown-o'></i> Oopsss....No attendance record found </style> ");

            }
 */