import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;


public class DeleteForumTopics extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        String qid=req.getParameter("qid");
        try
        {       
            Connection con=DB_Connection.get_DBConnection();

            PreparedStatement pst=con.prepareStatement("delete from question where id=?");
            pst.setString(1,qid);
            pst.executeUpdate();
            pst.close();
      
            RequestDispatcher rd=req.getRequestDispatcher("ViewForumTopics");
            rd.forward(req,res);
               
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }        
}