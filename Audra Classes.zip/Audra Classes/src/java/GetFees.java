import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;
import p1.*;

public class GetFees extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
       
        try
        {
           
        String c=req.getParameter("c");
        Connection con=DB_Connection.get_DBConnection();
        Calendar cl=Calendar.getInstance();
       
        PreparedStatement pst=con.prepareStatement("select * from class where cname=?");
        pst.setString(1, c);
        ResultSet rs=pst.executeQuery();
        rs.next();
        pw.println(rs.getString("fees"));
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}