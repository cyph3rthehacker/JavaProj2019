import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;


public class DeleteStudent extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        String sid=req.getParameter("sid");
        try
        {
       
            Connection con=DB_Connection.get_DBConnection();


            PreparedStatement pst=con.prepareStatement("delete from students where sid=?");
            pst.setString(1,sid);
            pst.executeUpdate();
            pst.close();
            
            pst=con.prepareStatement("delete from login where userid=?");
            pst.setString(1,req.getParameter("e"));
            pst.executeUpdate();
            pst.close();
      
            RequestDispatcher rd=req.getRequestDispatcher("ViewStudents");
            rd.forward(req,res);
         
           
        }
        catch(Exception e)
        {
            pw.println(e);
        }
    }
        
}