
import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import p1.*;

 public class GetStudentName extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
       PrintWriter pw=res.getWriter();
        
        try
        {      
        String sid=req.getParameter("sid");
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst1=con.prepareStatement("Select * from students where sid=?");
        pst1.setString(1,sid);
        ResultSet rs=pst1.executeQuery();
        rs.next();
        pw.println(rs.getString("name")+"-"+rs.getString("class")+"-"+rs.getString("fees")+"-"+rs.getString("bal"));
        }
        catch(Exception e)
        {
           
        }
    }
        
}